package com.sinosoft.newagriprpall.webservice.dto;

public class ResponseUnderwriteSubmitDto {
	/**
	 * ҵ������
	 */
	private String flowId;

	public String getFlowId() {
		return flowId;
	}

	public void setFlowId(String flowId) {
		this.flowId = flowId;
	}
	
}
