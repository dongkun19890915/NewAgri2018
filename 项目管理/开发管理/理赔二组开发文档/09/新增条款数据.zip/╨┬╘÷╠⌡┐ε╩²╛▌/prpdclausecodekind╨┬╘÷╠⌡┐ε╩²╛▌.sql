prompt Importing table prpdclausecodekind...
set feedback off
set define off
insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', 1, '3107M001', '11121', 'Y11', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', 2, '3107M001', '11122', 'Y11', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', 1, '3155M001', '11121', 'Y11', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', 2, '3155M001', '11122', 'Y11', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', 1, '3162M001', '11130', 'Y11000', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', 2, '3102M001', '331c3', 'Y11000', '52020', to_date('29-04-2018 15:55:00', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('29-04-2018 15:55:00', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', 1, '3102M001', '331c1', 'Y11000', '52020', to_date('29-04-2018 15:54:59', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('29-04-2018 15:54:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', 1, '3108M001', '22210', 'Y11', '0537', to_date('27-03-2018 10:32:09', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', 1, '3155M001', '11121', 'Y11', '0537', to_date('26-02-2018 15:59:24', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', 2, '3155M001', '11122', 'Y11', '0537', to_date('26-02-2018 15:59:26', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', 1, '3130M001', '44320', 'Y11', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', 2, '3130M001', 'AA110', 'Y11', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', 3, '3130M001', 'AA120', 'Y11', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', 4, '3130M001', 'AA130', 'Y11', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', 5, '3130M001', 'AA150', 'Y11', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', 6, '3130M001', 'AA210', 'Y11', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', 7, '3130M001', 'AA220', 'Y11', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', 8, '3130M001', 'AA230', 'Y11', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', 9, '3130M001', 'AA250', 'Y11', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', 1, '3220M001', 'bb110', 'Y11000', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', 1, '3141M001', '331c1', 'Y11', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', 2, '3141M001', '331c2', 'Y11', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', 3, '3141M001', '331c3', 'Y11', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', 4, '3141M001', '331c4', 'Y11', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', 5, '3141M001', 'AA110', 'Y11', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', 6, '3141M001', 'AA120', 'Y11', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', 7, '3141M001', 'AA130', 'Y11', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', 8, '3141M001', 'AA140', 'Y11', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', 9, '3141M001', 'AA210', 'Y11', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', 10, '3141M001', 'AA220', 'Y11', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', 11, '3141M001', 'AA230', 'Y11', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', 12, '3141M001', 'AA240', 'Y11', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', 13, '3141A001', '331c0', 'N12', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', 14, '3141A004', '331c0', 'N12', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', 1, '3134M001', '331c0', 'Y11', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', 2, '3134A002', '331c0', 'N12', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', 3, '3134A003', '331c0', 'N12', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', 1, '3224M001', 'dd210', 'Y11000', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', 2, '3224A002', 'dd210', 'N12000', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', 3, '3224A003', 'dd210', 'N12000', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', 1, '3102M002', '331c1', 'Y11000', '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', 2, '3102M002', '331c3', 'Y11000', '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', 1, '3147M001', '331c1', 'Y11000', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', 2, '3147M001', '331c2', 'Y11000', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', 3, '3147M001', '331c3', 'Y11000', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', 4, '3147A001', '331c0', 'N12', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', 5, '3147A003', '331c0', 'N12', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', 1, '3141M001', '331c1', 'Y11', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', 2, '3141M001', '331c2', 'Y11', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', 3, '3141M001', '331c3', 'Y11', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', 4, '3141M001', '331c4', 'Y11', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', 5, '3141M001', 'AA110', 'Y11', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', 6, '3141M001', 'AA120', 'Y11', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', 7, '3141M001', 'AA130', 'Y11', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', 8, '3141M001', 'AA140', 'Y11', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', 9, '3141M001', 'AA210', 'Y11', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', 10, '3141M001', 'AA220', 'Y11', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', 11, '3141M001', 'AA230', 'Y11', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', 12, '3141M001', 'AA240', 'Y11', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', 13, '3141A001', '331c0', 'N12', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', 14, '3141A004', '331c0', 'N12', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', 1, '3129M001', '44320', 'Y11', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', 2, '3129M001', 'AA110', 'Y11', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', 3, '3129M001', 'AA120', 'Y11', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', 4, '3129M001', 'AA130', 'Y11', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', 5, '3129M001', 'AA150', 'Y11', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', 6, '3129M001', 'AA210', 'Y11', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', 7, '3129M001', 'AA220', 'Y11', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', 8, '3129M001', 'AA230', 'Y11', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', 9, '3129M001', 'AA250', 'Y11', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', 10, '3129M002', 'ZZ100', 'Y11', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', 11, '3129M002', 'ZZ200', 'Y11', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', 12, '3129M003', 'YY100', 'Y11', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', 1, '3224M001', 'dd210', 'Y11000', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', 2, '3224A002', 'dd210', 'N12000', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', 3, '3224A003', 'dd210', 'N12000', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodekind (CLAUSECODE, SERIALNO, KINDCODE, ITEMCODE, CALCULATEFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', 1, '3237M001', 'dd230', 'Y11000', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

prompt Done.
