prompt Importing table prpdclausecodecom...
set feedback off
set define off
insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266001100', '1', '���ݷֹ�˾ֱ��Ӫҵ��Ӫҵһ��', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000023', '1', '���ϱ��մ������޹�˾���ݷֹ�˾', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266001500', '1', '���ݷֹ�˾ֱ��Ӫҵ��Ӫҵ�岿', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266001400', '1', '���ݷֹ�˾ֱ��Ӫҵ��Ӫҵ�Ĳ�', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266001300', '1', '���ݷֹ�˾ֱ��Ӫҵ��Ӫҵ����', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000010', '1', '�˱������������۷������޹�˾���ݷֹ�˾', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000011', '1', '�㽭�ڱ����մ������޹�˾����Ӫҵ��', '0', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000021', '1', '���Ǳ��մ������޹�˾��ϪӪҵ��', '0', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000022', '1', '�����������մ������޹�˾������', '0', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000024', '1', '��������̩ƽ���վ������޹�˾���ݷֹ�˾', '0', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000006', '1', '�㽭�ڱ����մ������������', '0', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000007', '1', '�Ͻ����Ԫ����ó�����޹�˾������', '0', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000008', '1', '�㽭�ڱ����մ����Ͻڳ�����', '0', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000025', '1', '������������ԣ������������', '0', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000028', '1', '���ݳ�������������˾', '0', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000035', '1', '�ڱ����մ������޹�˾����Ϣ����Ӫҵ��', '0', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000034', '1', '�����ڵ���Դ�����������޹�˾������', '0', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000033', '1', '���������������ͬ��������������', '0', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000036', '1', '�������ѳ������������Ĵ�����', '0', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000037', '1', '���ڱ����������޹�˾���ݷֹ�˾������', '0', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5200000900', '1', '���ݷֹ�˾�г�������', '0', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5203000000', '1', '��������֧��˾', '1', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5203009900', '1', '��������֧��˾������ũҵ�ղ�', '0', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5203001100', '1', '��������֧��˾Ӫҵ��', '0', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5203000800', '1', '��������֧��˾�ͻ�����', '0', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5203000600', '1', '��������֧��˾ҵ�������', '0', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5203000500', '1', '��������֧��˾ũ�ղ�', '0', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5203000300', '1', '��������֧��˾�����Ʋ�', '0', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5203000200', '1', '��������֧��˾�ۺϹ�����', '0', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5203000100', '1', '��������֧��˾������', '0', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5203000001', '1', '��������֧��˾�ڱ����մ���������', '0', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5203000002', '1', '��������֧��˾���ϱ��մ������ݷֹ�˾������', '0', '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5200000000', '1', '���ݷֹ�˾', '1', '52020', to_date('09-04-2018 10:52:33', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:33', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5223000000', '1', 'ǭ��������֧��˾', '1', '52020', to_date('09-04-2018 10:52:33', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:33', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5223000200', '1', 'ǭ��������֧��˾�ۺϹ�����', '0', '52020', to_date('09-04-2018 10:52:33', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:33', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5223000100', '1', 'ǭ��������֧��˾������', '0', '52020', to_date('09-04-2018 10:52:33', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:33', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5223009900', '1', 'ǭ��������֧��˾������ũҵ�ղ�', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5223001100', '1', 'ǭ��������֧��˾Ӫҵ��', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5223000800', '1', 'ǭ��������֧��˾�ͻ�����', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5223000600', '1', 'ǭ��������֧��˾ҵ�������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5223000500', '1', 'ǭ��������֧��˾ũ�ղ�', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5223000300', '1', 'ǭ��������֧��˾�����Ʋ�', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5223000001', '1', 'ǭ���Ϻ�ΰ��������������޹�˾������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5223000002', '1', 'ǭ�����ڱ����հ���Ӫҵ��������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5205000000', '1', '�Ͻ�����֧��˾', '1', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5205000008', '1', '�Ͻ�����֧��˾��Ӻ���ΰ�����������������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5205000007', '1', '�Ͻ�����֧��˾���ݺ���ó�׳�����', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5205000006', '1', '�Ͻ�����֧��˾�������������ۺϷ��������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5205000005', '1', '�Ͻ����Ԫ����ó�����޹�˾������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5205000500', '1', '�Ͻ�����֧��˾ũ�ղ�', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5205001100', '1', '�Ͻ�����֧��˾Ӫҵ��', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5205009900', '1', '�Ͻ�����֧��˾������ũҵ�ղ�', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5205000800', '1', '�Ͻ�����֧��˾�ͻ�����', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5205000600', '1', '�Ͻ�����֧��˾ҵ�������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5205000300', '1', '�Ͻ�����֧��˾�����Ʋ�', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5205000200', '1', '�Ͻ�����֧��˾�ۺϹ�����', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5205000100', '1', '�Ͻ�����֧��˾������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5205000003', '1', '�㽭�ڱ����մ����Ͻ�֯��Ӫҵ��', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5205000001', '1', '�Ͻ�����֧��˾�ڱ����մ���������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5205000002', '1', '�Ͻڴ��غ�г�����������޹�˾������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5205000004', '1', '����������ó���޹�˾�Ͻڷֹ�˾', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5202000000', '1', '����ˮ����֧��˾', '1', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5202009900', '1', '����ˮ����֧��˾������ũҵ�ղ�', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5202000800', '1', '����ˮ����֧��˾�ͻ�����', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5202000600', '1', '����ˮ����֧��˾ҵ�������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5202000300', '1', '����ˮ����֧��˾�����Ʋ�', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5202000200', '1', '����ˮ����֧��˾�ۺϹ�����', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5202000100', '1', '����ˮ����֧��˾������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5202001100', '1', '����ˮ����֧��˾Ӫҵ��', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5202000500', '1', '����ˮ����֧��˾ũ�ղ�', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5202000006', '1', '����ˮ��ɽ���ݱ�����ά�޹�˾������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5202000007', '1', '�������մ������ݷֹ�˾������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5202000005', '1', '����ˮ��Զ����������˾������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5202000004', '1', '����ˮ�ڱ����մ���������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5202000003', '1', '����ˮ����ǭ˳����������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5202000002', '1', '����ˮ��Ӻ���ΰ�����������������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5202000001', '1', '����ˮ���������������޹�˾', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5202000008', '1', '����ˮ��ɽ���������ά�޷������޹�˾', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5202000009', '1', '����ˮ���������������޹�˾������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5200000100', '1', '���ݷֹ�˾������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5200000200', '1', '���ݷֹ�˾�ۺϹ�����', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5200000300', '1', '���ݷֹ�˾�����Ʋ�', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5200000500', '1', '���ݷֹ�˾ũҵ���ղ�', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5200000600', '1', '���ݷֹ�˾ҵ�������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5200000800', '1', '���ݷֹ�˾�ͻ�����', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000000', '1', '���ݷֹ�˾ֱ��Ӫҵ��', '1', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000030', '1', '���ݷֹ�˾��������������ι�˾������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000002', '1', '���ݿ�������������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000012', '1', '��������������������������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000029', '1', '���ݷֹ�˾ʥԴ�鱣�մ������޹�˾������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000032', '1', '�ڱ����մ������޹�˾��˳Ӫҵ��', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000031', '1', '�찲��ӯ�����������޹�˾������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000003', '1', '�㽭�ڱ����մ���������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000004', '1', '����ˮ���������������޹�˾', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000027', '1', '���ݽ���������������޹�˾', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000026', '1', '����ʢ�ι��̻�е�������޹�˾', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000005', '1', '����ǭ�����ݶ������޳�����', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000014', '1', '��˳��������ɽ������������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000017', '1', '����껿��������޹�˾', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000016', '1', '�ڱ����մ������޹�˾����Ӫҵ��', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000015', '1', '�ڱ����մ������޹�˾����Ӫҵ��', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000018', '1', '���ϱ����������޹�˾���ݷֹ�˾', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000019', '1', '�㽭�ڱ����մ����Ͻ�֯��Ӫҵ��', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000013', '1', '����ǭ˳����ó�׹�˾', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000009', '1', '��˳��������������������������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266001200', '1', '���ݷֹ�˾ֱ��Ӫҵ��Ӫҵ����', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000020', '1', '�������ճ�����', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000100', '1', '���ݷֹ�˾ֱ��Ӫҵ��������', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000200', '1', '���ݷֹ�˾ֱ��Ӫҵ���ۺϹ�����', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000300', '1', '���ݷֹ�˾ֱ��Ӫҵ�������Ʋ�', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000600', '1', '���ݷֹ�˾ֱ��Ӫҵ��ҵ��', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266000800', '1', '���ݷֹ�˾ֱ��Ӫҵ���ͻ�����', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310220180002', '5266009900', '1', '���ݷֹ�˾ֱ��Ӫҵ��������ũҵ�ղ�', '0', '52020', to_date('09-04-2018 10:52:34', 'dd-mm-yyyy hh24:mi:ss'), '52020', to_date('02-05-2018 13:56:23', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000000', '1', '�Ϸ�����֧��˾', '1', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000100', '1', '�Ϸ�����֧��˾�ܾ�����', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401230000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401230100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401230001', '1', '����������ó������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401239900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401230700', '1', '����֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401230600', '1', '����֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401230200', '1', '����֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401230002', '1', '������ũ�û�е������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401232000', '1', 'С��ׯ��Ӫ������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401232100', '1', '����֧��˾��ͤӪ������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401220000', '1', '�ʶ�֧��˾', '1', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401229900', '1', '�ʶ�֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401220700', '1', '�ʶ�֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401220600', '1', '�ʶ�֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401220200', '1', '�ʶ�֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401220100', '1', '�ʶ�֧��˾������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401220001', '1', '�ʶ�ũ��վ������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401220002', '1', '���մ��籣�մ������޹�˾', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401222000', '1', '�ʶ�֧��˾�˶�Ӫ������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401220003', '1', '�ʶ�֧��˾ԣ¡���ܹ���վ������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3414000000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3414009900', '1', '����֧��˾������ũҵ�ղ�', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3414000500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3414000400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3414000300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3414000200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3414000100', '1', '����֧��˾�ܾ�����', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3414001200', '1', '�ӳ���ũҵ���շ���', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3414001900', '1', '������ũҵ���շ���', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3414000800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3414000003', '1', '����ŷ����ó������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3414000004', '1', '�����Žᶫ·֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3414000005', '1', '����Ӣ��֮���������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3414000006', '1', '�����������������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000200', '1', '�Ϸ�����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000300', '1', '�Ϸ�����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000400', '1', '�Ϸ�����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400006600', '1', '���չ�����˾', '1', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400006601', '1', '��̫���չ���', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3414210000', '1', '®��֧��˾', '1', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3414210200', '1', '®��֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3414210100', '1', '®��֧��˾������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3414210600', '1', '®��֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3414210700', '1', '®��֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3414219900', '1', '®��֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3414210002', '1', '®��ũ��վ������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3414210001', '1', '����®����Խ����������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3414210003', '1', '®�������ǳ�����', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401210000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401210100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401210200', '1', '����֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401210600', '1', '����֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401210700', '1', '����֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401219900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401210002', '1', '�����Դ����վ������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000039', '1', '�Ϸ�����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000000', '1', '�Ϸ�����֧��˾', '1', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000100', '1', '�Ϸ�����֧��˾�ܾ�����', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401230000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401230100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401230001', '1', '����������ó������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401239900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401230700', '1', '����֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401230600', '1', '����֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401230200', '1', '����֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401230002', '1', '������ũ�û�е������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401232000', '1', 'С��ׯ��Ӫ������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401232100', '1', '����֧��˾��ͤӪ������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401220000', '1', '�ʶ�֧��˾', '1', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401229900', '1', '�ʶ�֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401220700', '1', '�ʶ�֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401220600', '1', '�ʶ�֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401220200', '1', '�ʶ�֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401220100', '1', '�ʶ�֧��˾������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401220001', '1', '�ʶ�ũ��վ������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401220002', '1', '���մ��籣�մ������޹�˾', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401222000', '1', '�ʶ�֧��˾�˶�Ӫ������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401220003', '1', '�ʶ�֧��˾ԣ¡���ܹ���վ������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3414000000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3414009900', '1', '����֧��˾������ũҵ�ղ�', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3414000500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3414000400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3414000300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3414000200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3414000100', '1', '����֧��˾�ܾ�����', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3414001200', '1', '�ӳ���ũҵ���շ���', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3414001900', '1', '������ũҵ���շ���', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3414000800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3414000003', '1', '����ŷ����ó������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3414000004', '1', '�����Žᶫ·֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3414000005', '1', '����Ӣ��֮���������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3414000006', '1', '�����������������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000200', '1', '�Ϸ�����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000300', '1', '�Ϸ�����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000400', '1', '�Ϸ�����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400006600', '1', '���չ�����˾', '1', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400006601', '1', '��̫���չ���', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3414210000', '1', '®��֧��˾', '1', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3414210200', '1', '®��֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3414210100', '1', '®��֧��˾������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3414210600', '1', '®��֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3414210700', '1', '®��֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3414219900', '1', '®��֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401010015', '1', '�Ϸ���֧Ӫҵ���Ϸ���������������˾������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3414210002', '1', '®��ũ��վ������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3414210001', '1', '����®����Խ����������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3414210003', '1', '®�������ǳ�����', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401210000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401210100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401230100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401230001', '1', '����������ó������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401239900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401230700', '1', '����֧��˾���۲�', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401230600', '1', '����֧��˾ҵ��', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401230200', '1', '����֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401230002', '1', '������ũ�û�е������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401232000', '1', 'С��ׯ��Ӫ������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401232100', '1', '����֧��˾��ͤӪ������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401220000', '1', '�ʶ�֧��˾', '1', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401229900', '1', '�ʶ�֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401220700', '1', '�ʶ�֧��˾���۲�', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401220600', '1', '�ʶ�֧��˾ҵ��', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401220200', '1', '�ʶ�֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401220100', '1', '�ʶ�֧��˾������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401220001', '1', '�ʶ�ũ��վ������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401220002', '1', '���մ��籣�մ������޹�˾', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401222000', '1', '�ʶ�֧��˾�˶�Ӫ������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401220003', '1', '�ʶ�֧��˾ԣ¡���ܹ���վ������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3414000000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3414009900', '1', '����֧��˾������ũҵ�ղ�', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3414000500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3414000400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3414000300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3414000200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3414000100', '1', '����֧��˾�ܾ�����', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3414001200', '1', '�ӳ���ũҵ���շ���', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3414001900', '1', '������ũҵ���շ���', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3414000800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3414000003', '1', '����ŷ����ó������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3414000004', '1', '�����Žᶫ·֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3414000005', '1', '����Ӣ��֮���������۷������޹�˾������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3414000006', '1', '�����������������۷������޹�˾������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000200', '1', '�Ϸ�����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000300', '1', '�Ϸ�����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000400', '1', '�Ϸ�����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400006600', '1', '���չ�����˾', '1', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400006601', '1', '��̫���չ���', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3414210000', '1', '®��֧��˾', '1', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3414210200', '1', '®��֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3414210100', '1', '®��֧��˾������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3414210600', '1', '®��֧��˾ҵ��', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3414210700', '1', '®��֧��˾���۲�', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3414219900', '1', '®��֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3414210002', '1', '®��ũ��վ������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3414210001', '1', '����®����Խ����������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3414210003', '1', '®�������ǳ�����', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401210000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401210100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401210200', '1', '����֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401210600', '1', '����֧��˾ҵ��', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401210700', '1', '����֧��˾���۲�', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401219900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401210002', '1', '�����Դ����վ������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401210001', '1', '����ũ��վ������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401212000', '1', '����֧��˾����Ӫ������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000002', '1', '�Ϸ�����֧��˾������ó������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000006', '1', '�Ϸ�����֧��˾����������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000005', '1', '�Ϸ�����֧��˾������������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400009900', '1', '�Ϸ�����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000010', '1', '�Ϸ�����֧��˾�������������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000009', '1', '�Ϸ�����֧��˾������ó������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000004', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000800', '1', '�Ϸ�����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000900', '1', '�Ϸ�����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000011', '1', '�Ϸ�����֧��˾��̩���մ���������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000014', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000015', '1', '�Ϸ�����֧��˾��̩����������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000012', '1', '�Ϸ�����֧��˾���Ǳ��վ��ͳ�����', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000013', '1', '�Ϸ�����֧��˾����ɽ�������Ĵ���������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000003', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000008', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000007', '1', '�Ϸ�����֧��˾��˳��ó������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000016', '1', '�Ϸ�����֧��˾��÷�����������޹�˾', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000017', '1', '�Ϸ����������������޹�˾', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000018', '1', '�Ϸ�����·֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000019', '1', '�Ϸʽ�կ·��������֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401020000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401020100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401020200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401020300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401020400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401020500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401020800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401029900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401210001', '1', '����ũ��վ������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401212000', '1', '����֧��˾����Ӫ������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000002', '1', '�Ϸ�����֧��˾������ó������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000006', '1', '�Ϸ�����֧��˾����������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000005', '1', '�Ϸ�����֧��˾������������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400009900', '1', '�Ϸ�����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000010', '1', '�Ϸ�����֧��˾�������������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000009', '1', '�Ϸ�����֧��˾������ó������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000004', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000800', '1', '�Ϸ�����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000900', '1', '�Ϸ�����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000011', '1', '�Ϸ�����֧��˾��̩���մ���������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000014', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000015', '1', '�Ϸ�����֧��˾��̩����������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000012', '1', '�Ϸ�����֧��˾���Ǳ��վ��ͳ�����', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000013', '1', '�Ϸ�����֧��˾����ɽ�������Ĵ���������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000003', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000008', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000007', '1', '�Ϸ�����֧��˾��˳��ó������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000016', '1', '�Ϸ�����֧��˾��÷�����������޹�˾', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000017', '1', '�Ϸ����������������޹�˾', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000018', '1', '�Ϸ�����·֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000019', '1', '�Ϸʽ�կ·��������֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401020000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401020100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401020200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401020300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401020400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401020500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401020800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401029900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401020001', '1', '����֧��˾�������ճ�����', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401020002', '1', '����֧��˾�����𰲱��ճ�����', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401020003', '1', '����֧��˾�������������������޹�˾', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000020', '1', '��������������۷������޹�˾', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401110000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401119900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401110001', '1', '�Ϸ��н����ػ��������޹�˾������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401110100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401110200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401110300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401110400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401110500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401110800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401110002', '1', '����֧��˾���ս����������۳�����', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401110003', '1', '����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401110004', '1', '����֧��˾�Ϸʲ��Ӻ�����ó������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401110005', '1', '����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000021', '1', '���հ��������������޹�˾������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000022', '1', '����Э�ͱ��մ�����Ǻ�ΰ������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000023', '1', '�����������մ����ʶ��ֹ�˾������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000024', '1', '�Ϸ��н�������������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000025', '1', '�Ϸ�����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000026', '1', '�Ϸ�����֧��˾���տ�������������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000027', '1', '�Ϸ�����֧��˾�Ϸ��������������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000028', '1', '�Ϸ�����֧��˾�������ı��վ��ͳ�����', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000029', '1', '�Ϸ�����֧��˾���������������۳�����', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000030', '1', '�Ϸ�����֧��˾�����������Ƿֹ�˾������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000031', '1', '�Ϸ�����֧��˾�𰲱��մ���������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000033', '1', '�Ϸ�����֧��˾������ó����������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000034', '1', '�Ϸ�����֧��˾���ջݷ�����������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000032', '1', '�Ϸ�����֧��˾���ջݺ�����������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000035', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000036', '1', '�Ϸ�����֧��˾���������������۹�˾������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000037', '1', '�����׺������������޹�˾������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000038', '1', '����̩Դ�������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401010000', '1', '�Ϸ�����֧��˾Ӫҵ��', '1', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401019900', '1', '�Ϸ�����֧��˾Ӫҵ��������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401010800', '1', '�Ϸ�����֧��˾Ӫҵ���ͻ�����', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401010500', '1', '�Ϸ�����֧��˾Ӫҵ��ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401010400', '1', '�Ϸ�����֧��˾Ӫҵ���Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401010300', '1', '�Ϸ�����֧��˾Ӫҵ�������Ʋ�', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401010200', '1', '�Ϸ�����֧��˾Ӫҵ���ۺϹ�����', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401010100', '1', '�Ϸ�����֧��˾Ӫҵ��������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401010001', '1', '�Ϸ���֧�����񰲱��մ���������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401010013', '1', '�Ϸ���֧Ӫҵ�����������������޹�˾������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401010004', '1', '�Ϸ���֧Ӫҵ��������������������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401010005', '1', '�Ϸ���֧Ӫҵ�����ջݷ�����������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401010006', '1', '�Ϸ���֧Ӫҵ�����ջݺ�����������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401010007', '1', '����̩Դ�������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401020001', '1', '����֧��˾�������ճ�����', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401020002', '1', '����֧��˾�����𰲱��ճ�����', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401020003', '1', '����֧��˾�������������������޹�˾', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000020', '1', '��������������۷������޹�˾', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401110000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401119900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401110001', '1', '�Ϸ��н����ػ��������޹�˾������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401110100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401110200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401110300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401110400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401110500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401110800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401110002', '1', '����֧��˾���ս����������۳�����', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401110003', '1', '����֧��˾������������������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401110004', '1', '����֧��˾�Ϸʲ��Ӻ�����ó������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401110005', '1', '����֧��˾������������������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000021', '1', '���հ��������������޹�˾������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000022', '1', '����Э�ͱ��մ�����Ǻ�ΰ������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000023', '1', '�����������մ����ʶ��ֹ�˾������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000024', '1', '�Ϸ��н�������������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000025', '1', '�Ϸ�����֧��˾������������������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000026', '1', '�Ϸ�����֧��˾���տ�������������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000027', '1', '�Ϸ�����֧��˾�Ϸ��������������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000028', '1', '�Ϸ�����֧��˾�������ı��վ��ͳ�����', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000029', '1', '�Ϸ�����֧��˾���������������۳�����', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000030', '1', '�Ϸ�����֧��˾�����������Ƿֹ�˾������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000031', '1', '�Ϸ�����֧��˾�𰲱��մ���������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000033', '1', '�Ϸ�����֧��˾������ó����������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000034', '1', '�Ϸ�����֧��˾���ջݷ�����������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000032', '1', '�Ϸ�����֧��˾���ջݺ�����������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000035', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000036', '1', '�Ϸ�����֧��˾���������������۹�˾������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000037', '1', '�����׺������������޹�˾������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000038', '1', '����̩Դ�������۷������޹�˾������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401010000', '1', '�Ϸ�����֧��˾Ӫҵ��', '1', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401019900', '1', '�Ϸ�����֧��˾Ӫҵ��������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401010800', '1', '�Ϸ�����֧��˾Ӫҵ���ͻ�����', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401010500', '1', '�Ϸ�����֧��˾Ӫҵ��ũҵ���ղ�', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401010400', '1', '�Ϸ�����֧��˾Ӫҵ���Ʋ����ղ�', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401010300', '1', '�Ϸ�����֧��˾Ӫҵ�������Ʋ�', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401010200', '1', '�Ϸ�����֧��˾Ӫҵ���ۺϹ�����', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401010100', '1', '�Ϸ�����֧��˾Ӫҵ��������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401010001', '1', '�Ϸ���֧�����񰲱��մ���������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401010013', '1', '�Ϸ���֧Ӫҵ�����������������޹�˾������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401010004', '1', '�Ϸ���֧Ӫҵ��������������������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401010005', '1', '�Ϸ���֧Ӫҵ�����ջݷ�����������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401010006', '1', '�Ϸ���֧Ӫҵ�����ջݺ�����������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401010007', '1', '����̩Դ�������۷������޹�˾������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401010002', '1', '�������˱������۹ɷݹɷݹ�˾���շֹ�˾������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401010012', '1', '�Ϸ���֧Ӫҵ����÷���մ������޹�˾���շֹ�˾', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401010010', '1', '�Ϸ���֧Ӫҵ�����鱣���������޹�˾���շֹ�˾', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401010014', '1', '�Ϸ���֧Ӫҵ������ͬ�±��մ������޹�˾������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401010003', '1', '�Ϸ���֧�����ɻ������г�������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401010008', '1', '�Ϸ���֧Ӫҵ����������������۳�����', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401010009', '1', '�Ϸ���֧Ӫҵ���Ϸ���ͨ�������۳�����', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401010011', '1', '�Ϸ���֧Ӫҵ������Э�ͱ��մ������޹�˾', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401010015', '1', '�Ϸ���֧Ӫҵ���Ϸ���������������˾������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000039', '1', '�Ϸ�����֧��˾������������������', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401010002', '1', '�������˱������۹ɷݹɷݹ�˾���շֹ�˾������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401010012', '1', '�Ϸ���֧Ӫҵ����÷���մ������޹�˾���շֹ�˾', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401010010', '1', '�Ϸ���֧Ӫҵ�����鱣���������޹�˾���շֹ�˾', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401010014', '1', '�Ϸ���֧Ӫҵ������ͬ�±��մ������޹�˾������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401010003', '1', '�Ϸ���֧�����ɻ������г�������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401010008', '1', '�Ϸ���֧Ӫҵ����������������۳�����', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401010009', '1', '�Ϸ���֧Ӫҵ���Ϸ���ͨ�������۳�����', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401010011', '1', '�Ϸ���֧Ӫҵ������Э�ͱ��մ������޹�˾', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3401010015', '1', '�Ϸ���֧Ӫҵ���Ϸ���������������˾������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310720180031', '3400000039', '1', '�Ϸ�����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:34:37', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000000', '1', '�Ϸ�����֧��˾', '1', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000100', '1', '�Ϸ�����֧��˾�ܾ�����', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401230000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401230100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401230001', '1', '����������ó������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401239900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401230700', '1', '����֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401230600', '1', '����֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401230200', '1', '����֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401230002', '1', '������ũ�û�е������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401232000', '1', 'С��ׯ��Ӫ������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401232100', '1', '����֧��˾��ͤӪ������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401220000', '1', '�ʶ�֧��˾', '1', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401229900', '1', '�ʶ�֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401220700', '1', '�ʶ�֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401220600', '1', '�ʶ�֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401220200', '1', '�ʶ�֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401220100', '1', '�ʶ�֧��˾������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401220001', '1', '�ʶ�ũ��վ������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401220002', '1', '���մ��籣�մ������޹�˾', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401222000', '1', '�ʶ�֧��˾�˶�Ӫ������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401220003', '1', '�ʶ�֧��˾ԣ¡���ܹ���վ������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3414000000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3414009900', '1', '����֧��˾������ũҵ�ղ�', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3414000500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3414000400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3414000300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3414000200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3414000100', '1', '����֧��˾�ܾ�����', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3414001200', '1', '�ӳ���ũҵ���շ���', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3414001900', '1', '������ũҵ���շ���', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3414000800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3414000003', '1', '����ŷ����ó������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3414000004', '1', '�����Žᶫ·֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3414000005', '1', '����Ӣ��֮���������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3414000006', '1', '�����������������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000200', '1', '�Ϸ�����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000300', '1', '�Ϸ�����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000400', '1', '�Ϸ�����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400006600', '1', '���չ�����˾', '1', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400006601', '1', '��̫���չ���', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3414210000', '1', '®��֧��˾', '1', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3414210200', '1', '®��֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3414210100', '1', '®��֧��˾������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3414210600', '1', '®��֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3414210700', '1', '®��֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3414219900', '1', '®��֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3414210002', '1', '®��ũ��վ������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3414210001', '1', '����®����Խ����������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3414210003', '1', '®�������ǳ�����', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401210000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401210100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401210200', '1', '����֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401210600', '1', '����֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401210700', '1', '����֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401219900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401210002', '1', '�����Դ����վ������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401210001', '1', '����ũ��վ������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401212000', '1', '����֧��˾����Ӫ������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000002', '1', '�Ϸ�����֧��˾������ó������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000006', '1', '�Ϸ�����֧��˾����������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000005', '1', '�Ϸ�����֧��˾������������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400009900', '1', '�Ϸ�����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000010', '1', '�Ϸ�����֧��˾�������������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000009', '1', '�Ϸ�����֧��˾������ó������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000004', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000800', '1', '�Ϸ�����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000900', '1', '�Ϸ�����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000011', '1', '�Ϸ�����֧��˾��̩���մ���������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000014', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000015', '1', '�Ϸ�����֧��˾��̩����������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000012', '1', '�Ϸ�����֧��˾���Ǳ��վ��ͳ�����', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000013', '1', '�Ϸ�����֧��˾����ɽ�������Ĵ���������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000003', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000008', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401210200', '1', '����֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401210600', '1', '����֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401210700', '1', '����֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401219900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401210002', '1', '�����Դ����վ������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401210001', '1', '����ũ��վ������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401212000', '1', '����֧��˾����Ӫ������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000002', '1', '�Ϸ�����֧��˾������ó������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000006', '1', '�Ϸ�����֧��˾����������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000005', '1', '�Ϸ�����֧��˾������������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400009900', '1', '�Ϸ�����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000010', '1', '�Ϸ�����֧��˾�������������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000009', '1', '�Ϸ�����֧��˾������ó������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000004', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000800', '1', '�Ϸ�����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000900', '1', '�Ϸ�����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000011', '1', '�Ϸ�����֧��˾��̩���մ���������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000014', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000015', '1', '�Ϸ�����֧��˾��̩����������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000012', '1', '�Ϸ�����֧��˾���Ǳ��վ��ͳ�����', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000013', '1', '�Ϸ�����֧��˾����ɽ�������Ĵ���������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000003', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000008', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000007', '1', '�Ϸ�����֧��˾��˳��ó������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000016', '1', '�Ϸ�����֧��˾��÷�����������޹�˾', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000017', '1', '�Ϸ����������������޹�˾', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000018', '1', '�Ϸ�����·֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000007', '1', '�Ϸ�����֧��˾��˳��ó������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000016', '1', '�Ϸ�����֧��˾��÷�����������޹�˾', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000017', '1', '�Ϸ����������������޹�˾', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000018', '1', '�Ϸ�����·֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000019', '1', '�Ϸʽ�կ·��������֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401020000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401020100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401020200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401020300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401020400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401020500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401020800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401029900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401020001', '1', '����֧��˾�������ճ�����', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401020002', '1', '����֧��˾�����𰲱��ճ�����', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401020003', '1', '����֧��˾�������������������޹�˾', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000020', '1', '��������������۷������޹�˾', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401110000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401119900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401110001', '1', '�Ϸ��н����ػ��������޹�˾������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401110100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401110200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401110300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401110400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401110500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401110800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401110002', '1', '����֧��˾���ս����������۳�����', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401110003', '1', '����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401110004', '1', '����֧��˾�Ϸʲ��Ӻ�����ó������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401110005', '1', '����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000021', '1', '���հ��������������޹�˾������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000022', '1', '����Э�ͱ��մ�����Ǻ�ΰ������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000023', '1', '�����������մ����ʶ��ֹ�˾������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000024', '1', '�Ϸ��н�������������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000025', '1', '�Ϸ�����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000026', '1', '�Ϸ�����֧��˾���տ�������������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000027', '1', '�Ϸ�����֧��˾�Ϸ��������������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000028', '1', '�Ϸ�����֧��˾�������ı��վ��ͳ�����', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000029', '1', '�Ϸ�����֧��˾���������������۳�����', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000030', '1', '�Ϸ�����֧��˾�����������Ƿֹ�˾������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000031', '1', '�Ϸ�����֧��˾�𰲱��մ���������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000033', '1', '�Ϸ�����֧��˾������ó����������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000034', '1', '�Ϸ�����֧��˾���ջݷ�����������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000032', '1', '�Ϸ�����֧��˾���ջݺ�����������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000035', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000036', '1', '�Ϸ�����֧��˾���������������۹�˾������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000037', '1', '�����׺������������޹�˾������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000038', '1', '����̩Դ�������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401010000', '1', '�Ϸ�����֧��˾Ӫҵ��', '1', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401019900', '1', '�Ϸ�����֧��˾Ӫҵ��������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401010800', '1', '�Ϸ�����֧��˾Ӫҵ���ͻ�����', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401010500', '1', '�Ϸ�����֧��˾Ӫҵ��ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401010400', '1', '�Ϸ�����֧��˾Ӫҵ���Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401010300', '1', '�Ϸ�����֧��˾Ӫҵ�������Ʋ�', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401010200', '1', '�Ϸ�����֧��˾Ӫҵ���ۺϹ�����', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401010100', '1', '�Ϸ�����֧��˾Ӫҵ��������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401010001', '1', '�Ϸ���֧�����񰲱��մ���������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401010013', '1', '�Ϸ���֧Ӫҵ�����������������޹�˾������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401010004', '1', '�Ϸ���֧Ӫҵ��������������������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401010005', '1', '�Ϸ���֧Ӫҵ�����ջݷ�����������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401010006', '1', '�Ϸ���֧Ӫҵ�����ջݺ�����������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401010007', '1', '����̩Դ�������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401010002', '1', '�������˱������۹ɷݹɷݹ�˾���շֹ�˾������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401010012', '1', '�Ϸ���֧Ӫҵ����÷���մ������޹�˾���շֹ�˾', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401010010', '1', '�Ϸ���֧Ӫҵ�����鱣���������޹�˾���շֹ�˾', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401010014', '1', '�Ϸ���֧Ӫҵ������ͬ�±��մ������޹�˾������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401010003', '1', '�Ϸ���֧�����ɻ������г�������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401010008', '1', '�Ϸ���֧Ӫҵ����������������۳�����', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401010009', '1', '�Ϸ���֧Ӫҵ���Ϸ���ͨ�������۳�����', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401010011', '1', '�Ϸ���֧Ӫҵ������Э�ͱ��մ������޹�˾', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3401010015', '1', '�Ϸ���֧Ӫҵ���Ϸ���������������˾������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK310820180004', '3400000039', '1', '�Ϸ�����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:38:11', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000000', '1', '�Ϸ�����֧��˾', '1', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000100', '1', '�Ϸ�����֧��˾�ܾ�����', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401230000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401230100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401230001', '1', '����������ó������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401239900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401230700', '1', '����֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401230600', '1', '����֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000019', '1', '�Ϸʽ�կ·��������֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401020000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401020100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401020200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401020300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401020400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401020500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401020800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401029900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401020001', '1', '����֧��˾�������ճ�����', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401020002', '1', '����֧��˾�����𰲱��ճ�����', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401020003', '1', '����֧��˾�������������������޹�˾', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000020', '1', '��������������۷������޹�˾', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401110000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401119900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401110001', '1', '�Ϸ��н����ػ��������޹�˾������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401110100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401110200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401110300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401110400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401110500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401110800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401110002', '1', '����֧��˾���ս����������۳�����', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401110003', '1', '����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401110004', '1', '����֧��˾�Ϸʲ��Ӻ�����ó������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401110005', '1', '����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000021', '1', '���հ��������������޹�˾������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000022', '1', '����Э�ͱ��մ�����Ǻ�ΰ������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000023', '1', '�����������մ����ʶ��ֹ�˾������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000024', '1', '�Ϸ��н�������������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000025', '1', '�Ϸ�����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000026', '1', '�Ϸ�����֧��˾���տ�������������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000027', '1', '�Ϸ�����֧��˾�Ϸ��������������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000028', '1', '�Ϸ�����֧��˾�������ı��վ��ͳ�����', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000029', '1', '�Ϸ�����֧��˾���������������۳�����', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000030', '1', '�Ϸ�����֧��˾�����������Ƿֹ�˾������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000031', '1', '�Ϸ�����֧��˾�𰲱��մ���������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000033', '1', '�Ϸ�����֧��˾������ó����������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000034', '1', '�Ϸ�����֧��˾���ջݷ�����������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000032', '1', '�Ϸ�����֧��˾���ջݺ�����������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000035', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000036', '1', '�Ϸ�����֧��˾���������������۹�˾������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000037', '1', '�����׺������������޹�˾������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000038', '1', '����̩Դ�������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401010000', '1', '�Ϸ�����֧��˾Ӫҵ��', '1', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401019900', '1', '�Ϸ�����֧��˾Ӫҵ��������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401010800', '1', '�Ϸ�����֧��˾Ӫҵ���ͻ�����', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401010500', '1', '�Ϸ�����֧��˾Ӫҵ��ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401010400', '1', '�Ϸ�����֧��˾Ӫҵ���Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401010300', '1', '�Ϸ�����֧��˾Ӫҵ�������Ʋ�', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401010200', '1', '�Ϸ�����֧��˾Ӫҵ���ۺϹ�����', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401010100', '1', '�Ϸ�����֧��˾Ӫҵ��������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401010001', '1', '�Ϸ���֧�����񰲱��մ���������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401010013', '1', '�Ϸ���֧Ӫҵ�����������������޹�˾������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401010004', '1', '�Ϸ���֧Ӫҵ��������������������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401010005', '1', '�Ϸ���֧Ӫҵ�����ջݷ�����������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401010006', '1', '�Ϸ���֧Ӫҵ�����ջݺ�����������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401010007', '1', '����̩Դ�������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401010002', '1', '�������˱������۹ɷݹɷݹ�˾���շֹ�˾������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401010012', '1', '�Ϸ���֧Ӫҵ����÷���մ������޹�˾���շֹ�˾', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401010010', '1', '�Ϸ���֧Ӫҵ�����鱣���������޹�˾���շֹ�˾', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401010014', '1', '�Ϸ���֧Ӫҵ������ͬ�±��մ������޹�˾������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401010003', '1', '�Ϸ���֧�����ɻ������г�������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401010008', '1', '�Ϸ���֧Ӫҵ����������������۳�����', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401010009', '1', '�Ϸ���֧Ӫҵ���Ϸ���ͨ�������۳�����', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401010011', '1', '�Ϸ���֧Ӫҵ������Э�ͱ��մ������޹�˾', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3401010015', '1', '�Ϸ���֧Ӫҵ���Ϸ���������������˾������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314720180001', '3400000039', '1', '�Ϸ�����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:57:35', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000000', '1', '�Ϸ�����֧��˾', '1', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000100', '1', '�Ϸ�����֧��˾�ܾ�����', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401230000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401230100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401230001', '1', '����������ó������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401239900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401230700', '1', '����֧��˾���۲�', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401230600', '1', '����֧��˾ҵ��', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401230200', '1', '����֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401230002', '1', '������ũ�û�е������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401232000', '1', 'С��ׯ��Ӫ������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401232100', '1', '����֧��˾��ͤӪ������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401220000', '1', '�ʶ�֧��˾', '1', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401230200', '1', '����֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401230002', '1', '������ũ�û�е������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401232000', '1', 'С��ׯ��Ӫ������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401232100', '1', '����֧��˾��ͤӪ������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401220000', '1', '�ʶ�֧��˾', '1', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401229900', '1', '�ʶ�֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401220700', '1', '�ʶ�֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401220600', '1', '�ʶ�֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401220200', '1', '�ʶ�֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401220100', '1', '�ʶ�֧��˾������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401220001', '1', '�ʶ�ũ��վ������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401220002', '1', '���մ��籣�մ������޹�˾', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401222000', '1', '�ʶ�֧��˾�˶�Ӫ������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401220003', '1', '�ʶ�֧��˾ԣ¡���ܹ���վ������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3414000000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3414009900', '1', '����֧��˾������ũҵ�ղ�', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3414000500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3414000400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3414000300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3414000200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3414000100', '1', '����֧��˾�ܾ�����', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3414001200', '1', '�ӳ���ũҵ���շ���', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3414001900', '1', '������ũҵ���շ���', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3414000800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3414000003', '1', '����ŷ����ó������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3414000004', '1', '�����Žᶫ·֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3414000005', '1', '����Ӣ��֮���������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3414000006', '1', '�����������������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000200', '1', '�Ϸ�����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000300', '1', '�Ϸ�����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000400', '1', '�Ϸ�����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400006600', '1', '���չ�����˾', '1', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400006601', '1', '��̫���չ���', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3414210000', '1', '®��֧��˾', '1', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3414210200', '1', '®��֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3414210100', '1', '®��֧��˾������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3414210600', '1', '®��֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3414210700', '1', '®��֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3414219900', '1', '®��֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3414210002', '1', '®��ũ��վ������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3414210001', '1', '����®����Խ����������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3414210003', '1', '®�������ǳ�����', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401210000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401210100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401210200', '1', '����֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401210600', '1', '����֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401210700', '1', '����֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401219900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401210002', '1', '�����Դ����վ������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401210001', '1', '����ũ��վ������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401212000', '1', '����֧��˾����Ӫ������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000002', '1', '�Ϸ�����֧��˾������ó������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000006', '1', '�Ϸ�����֧��˾����������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000005', '1', '�Ϸ�����֧��˾������������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400009900', '1', '�Ϸ�����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000010', '1', '�Ϸ�����֧��˾�������������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000009', '1', '�Ϸ�����֧��˾������ó������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000004', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000800', '1', '�Ϸ�����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000900', '1', '�Ϸ�����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000011', '1', '�Ϸ�����֧��˾��̩���մ���������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000014', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000015', '1', '�Ϸ�����֧��˾��̩����������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000012', '1', '�Ϸ�����֧��˾���Ǳ��վ��ͳ�����', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000013', '1', '�Ϸ�����֧��˾����ɽ�������Ĵ���������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000003', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000008', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000007', '1', '�Ϸ�����֧��˾��˳��ó������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000016', '1', '�Ϸ�����֧��˾��÷�����������޹�˾', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000017', '1', '�Ϸ����������������޹�˾', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000018', '1', '�Ϸ�����·֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000019', '1', '�Ϸʽ�կ·��������֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401020000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401020100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401020200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401020300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401020400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401020500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401020800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401029900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401020001', '1', '����֧��˾�������ճ�����', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401020002', '1', '����֧��˾�����𰲱��ճ�����', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401020003', '1', '����֧��˾�������������������޹�˾', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000020', '1', '��������������۷������޹�˾', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401110000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401119900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401229900', '1', '�ʶ�֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401220700', '1', '�ʶ�֧��˾���۲�', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401220600', '1', '�ʶ�֧��˾ҵ��', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401220200', '1', '�ʶ�֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401220100', '1', '�ʶ�֧��˾������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401220001', '1', '�ʶ�ũ��վ������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401220002', '1', '���մ��籣�մ������޹�˾', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401222000', '1', '�ʶ�֧��˾�˶�Ӫ������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401220003', '1', '�ʶ�֧��˾ԣ¡���ܹ���վ������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3414000000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3414009900', '1', '����֧��˾������ũҵ�ղ�', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3414000500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3414000400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3414000300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3414000200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3414000100', '1', '����֧��˾�ܾ�����', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3414001200', '1', '�ӳ���ũҵ���շ���', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3414001900', '1', '������ũҵ���շ���', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3414000800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3414000003', '1', '����ŷ����ó������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3414000004', '1', '�����Žᶫ·֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3414000005', '1', '����Ӣ��֮���������۷������޹�˾������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3414000006', '1', '�����������������۷������޹�˾������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000200', '1', '�Ϸ�����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000300', '1', '�Ϸ�����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000400', '1', '�Ϸ�����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400006600', '1', '���չ�����˾', '1', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400006601', '1', '��̫���չ���', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3414210000', '1', '®��֧��˾', '1', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3414210200', '1', '®��֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3414210100', '1', '®��֧��˾������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3414210600', '1', '®��֧��˾ҵ��', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3414210700', '1', '®��֧��˾���۲�', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3414219900', '1', '®��֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3414210002', '1', '®��ũ��վ������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3414210001', '1', '����®����Խ����������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3414210003', '1', '®�������ǳ�����', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401210000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401210100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401210200', '1', '����֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401210600', '1', '����֧��˾ҵ��', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401210700', '1', '����֧��˾���۲�', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401219900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401210002', '1', '�����Դ����վ������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401210001', '1', '����ũ��վ������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401212000', '1', '����֧��˾����Ӫ������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000002', '1', '�Ϸ�����֧��˾������ó������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000006', '1', '�Ϸ�����֧��˾����������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000005', '1', '�Ϸ�����֧��˾������������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400009900', '1', '�Ϸ�����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000010', '1', '�Ϸ�����֧��˾�������������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000009', '1', '�Ϸ�����֧��˾������ó������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000004', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000800', '1', '�Ϸ�����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000900', '1', '�Ϸ�����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000011', '1', '�Ϸ�����֧��˾��̩���մ���������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000014', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000015', '1', '�Ϸ�����֧��˾��̩����������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000012', '1', '�Ϸ�����֧��˾���Ǳ��վ��ͳ�����', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000013', '1', '�Ϸ�����֧��˾����ɽ�������Ĵ���������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000003', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000008', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000007', '1', '�Ϸ�����֧��˾��˳��ó������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000016', '1', '�Ϸ�����֧��˾��÷�����������޹�˾', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000017', '1', '�Ϸ����������������޹�˾', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000018', '1', '�Ϸ�����·֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000019', '1', '�Ϸʽ�կ·��������֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401020000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401020100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401020200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401020300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401020400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401020500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401020800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401029900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401020001', '1', '����֧��˾�������ճ�����', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401020002', '1', '����֧��˾�����𰲱��ճ�����', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401020003', '1', '����֧��˾�������������������޹�˾', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000020', '1', '��������������۷������޹�˾', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401110000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401119900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401110001', '1', '�Ϸ��н����ػ��������޹�˾������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401110100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401110200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401110300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401110400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401110001', '1', '�Ϸ��н����ػ��������޹�˾������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401110100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401110200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401110300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401110400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401110500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401110800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401110002', '1', '����֧��˾���ս����������۳�����', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401110003', '1', '����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401110004', '1', '����֧��˾�Ϸʲ��Ӻ�����ó������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401110005', '1', '����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000021', '1', '���հ��������������޹�˾������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000022', '1', '����Э�ͱ��մ�����Ǻ�ΰ������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000023', '1', '�����������մ����ʶ��ֹ�˾������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000024', '1', '�Ϸ��н�������������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000025', '1', '�Ϸ�����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000026', '1', '�Ϸ�����֧��˾���տ�������������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000027', '1', '�Ϸ�����֧��˾�Ϸ��������������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000028', '1', '�Ϸ�����֧��˾�������ı��վ��ͳ�����', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000029', '1', '�Ϸ�����֧��˾���������������۳�����', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000030', '1', '�Ϸ�����֧��˾�����������Ƿֹ�˾������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000031', '1', '�Ϸ�����֧��˾�𰲱��մ���������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000033', '1', '�Ϸ�����֧��˾������ó����������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000034', '1', '�Ϸ�����֧��˾���ջݷ�����������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000032', '1', '�Ϸ�����֧��˾���ջݺ�����������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000035', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000036', '1', '�Ϸ�����֧��˾���������������۹�˾������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000037', '1', '�����׺������������޹�˾������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000038', '1', '����̩Դ�������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401010000', '1', '�Ϸ�����֧��˾Ӫҵ��', '1', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401019900', '1', '�Ϸ�����֧��˾Ӫҵ��������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401010800', '1', '�Ϸ�����֧��˾Ӫҵ���ͻ�����', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401010500', '1', '�Ϸ�����֧��˾Ӫҵ��ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401010400', '1', '�Ϸ�����֧��˾Ӫҵ���Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401010300', '1', '�Ϸ�����֧��˾Ӫҵ�������Ʋ�', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401010200', '1', '�Ϸ�����֧��˾Ӫҵ���ۺϹ�����', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401010100', '1', '�Ϸ�����֧��˾Ӫҵ��������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401010001', '1', '�Ϸ���֧�����񰲱��մ���������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401010013', '1', '�Ϸ���֧Ӫҵ�����������������޹�˾������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401010004', '1', '�Ϸ���֧Ӫҵ��������������������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401010005', '1', '�Ϸ���֧Ӫҵ�����ջݷ�����������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401010006', '1', '�Ϸ���֧Ӫҵ�����ջݺ�����������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401010007', '1', '����̩Դ�������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401010002', '1', '�������˱������۹ɷݹɷݹ�˾���շֹ�˾������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401010012', '1', '�Ϸ���֧Ӫҵ����÷���մ������޹�˾���շֹ�˾', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401010010', '1', '�Ϸ���֧Ӫҵ�����鱣���������޹�˾���շֹ�˾', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401010014', '1', '�Ϸ���֧Ӫҵ������ͬ�±��մ������޹�˾������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401010003', '1', '�Ϸ���֧�����ɻ������г�������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401010008', '1', '�Ϸ���֧Ӫҵ����������������۳�����', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401010009', '1', '�Ϸ���֧Ӫҵ���Ϸ���ͨ�������۳�����', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401010011', '1', '�Ϸ���֧Ӫҵ������Э�ͱ��մ������޹�˾', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3401010015', '1', '�Ϸ���֧Ӫҵ���Ϸ���������������˾������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180001', '3400000039', '1', '�Ϸ�����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:41:59', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000000', '1', '�Ϸ�����֧��˾', '1', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000100', '1', '�Ϸ�����֧��˾�ܾ�����', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401230000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401230100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401230001', '1', '����������ó������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401239900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401230700', '1', '����֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401230600', '1', '����֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401230200', '1', '����֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401230002', '1', '������ũ�û�е������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401232000', '1', 'С��ׯ��Ӫ������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401232100', '1', '����֧��˾��ͤӪ������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401220000', '1', '�ʶ�֧��˾', '1', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401229900', '1', '�ʶ�֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401220700', '1', '�ʶ�֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401220600', '1', '�ʶ�֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401220200', '1', '�ʶ�֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401220100', '1', '�ʶ�֧��˾������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401220001', '1', '�ʶ�ũ��վ������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401220002', '1', '���մ��籣�մ������޹�˾', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401222000', '1', '�ʶ�֧��˾�˶�Ӫ������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401220003', '1', '�ʶ�֧��˾ԣ¡���ܹ���վ������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3414000000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3414009900', '1', '����֧��˾������ũҵ�ղ�', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3414000500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3414000400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3414000300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3414000200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401110500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401110800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401110002', '1', '����֧��˾���ս����������۳�����', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401110003', '1', '����֧��˾������������������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401110004', '1', '����֧��˾�Ϸʲ��Ӻ�����ó������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401110005', '1', '����֧��˾������������������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000021', '1', '���հ��������������޹�˾������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000022', '1', '����Э�ͱ��մ�����Ǻ�ΰ������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000023', '1', '�����������մ����ʶ��ֹ�˾������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000024', '1', '�Ϸ��н�������������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000025', '1', '�Ϸ�����֧��˾������������������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000026', '1', '�Ϸ�����֧��˾���տ�������������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000027', '1', '�Ϸ�����֧��˾�Ϸ��������������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000028', '1', '�Ϸ�����֧��˾�������ı��վ��ͳ�����', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000029', '1', '�Ϸ�����֧��˾���������������۳�����', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000030', '1', '�Ϸ�����֧��˾�����������Ƿֹ�˾������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000031', '1', '�Ϸ�����֧��˾�𰲱��մ���������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000033', '1', '�Ϸ�����֧��˾������ó����������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000034', '1', '�Ϸ�����֧��˾���ջݷ�����������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000032', '1', '�Ϸ�����֧��˾���ջݺ�����������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000035', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000036', '1', '�Ϸ�����֧��˾���������������۹�˾������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000037', '1', '�����׺������������޹�˾������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000038', '1', '����̩Դ�������۷������޹�˾������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401010000', '1', '�Ϸ�����֧��˾Ӫҵ��', '1', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401019900', '1', '�Ϸ�����֧��˾Ӫҵ��������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401010800', '1', '�Ϸ�����֧��˾Ӫҵ���ͻ�����', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401010500', '1', '�Ϸ�����֧��˾Ӫҵ��ũҵ���ղ�', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401010400', '1', '�Ϸ�����֧��˾Ӫҵ���Ʋ����ղ�', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401010300', '1', '�Ϸ�����֧��˾Ӫҵ�������Ʋ�', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401010200', '1', '�Ϸ�����֧��˾Ӫҵ���ۺϹ�����', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401010100', '1', '�Ϸ�����֧��˾Ӫҵ��������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401010001', '1', '�Ϸ���֧�����񰲱��մ���������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401010013', '1', '�Ϸ���֧Ӫҵ�����������������޹�˾������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401010004', '1', '�Ϸ���֧Ӫҵ��������������������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401010005', '1', '�Ϸ���֧Ӫҵ�����ջݷ�����������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401010006', '1', '�Ϸ���֧Ӫҵ�����ջݺ�����������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401010007', '1', '����̩Դ�������۷������޹�˾������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401010002', '1', '�������˱������۹ɷݹɷݹ�˾���շֹ�˾������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401010012', '1', '�Ϸ���֧Ӫҵ����÷���մ������޹�˾���շֹ�˾', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401010010', '1', '�Ϸ���֧Ӫҵ�����鱣���������޹�˾���շֹ�˾', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401010014', '1', '�Ϸ���֧Ӫҵ������ͬ�±��մ������޹�˾������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401010003', '1', '�Ϸ���֧�����ɻ������г�������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401010008', '1', '�Ϸ���֧Ӫҵ����������������۳�����', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401010009', '1', '�Ϸ���֧Ӫҵ���Ϸ���ͨ�������۳�����', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401010011', '1', '�Ϸ���֧Ӫҵ������Э�ͱ��մ������޹�˾', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3401010015', '1', '�Ϸ���֧Ӫҵ���Ϸ���������������˾������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180003', '3400000039', '1', '�Ϸ�����֧��˾������������������', '0', '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:02:51', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000000', '1', '�Ϸ�����֧��˾', '1', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000100', '1', '�Ϸ�����֧��˾�ܾ�����', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401230000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401230100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401230001', '1', '����������ó������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401239900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401230700', '1', '����֧��˾���۲�', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401230600', '1', '����֧��˾ҵ��', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401230200', '1', '����֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401230002', '1', '������ũ�û�е������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401232000', '1', 'С��ׯ��Ӫ������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401232100', '1', '����֧��˾��ͤӪ������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401220000', '1', '�ʶ�֧��˾', '1', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401229900', '1', '�ʶ�֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401220700', '1', '�ʶ�֧��˾���۲�', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401220600', '1', '�ʶ�֧��˾ҵ��', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401220200', '1', '�ʶ�֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401220100', '1', '�ʶ�֧��˾������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401220001', '1', '�ʶ�ũ��վ������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401220002', '1', '���մ��籣�մ������޹�˾', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401222000', '1', '�ʶ�֧��˾�˶�Ӫ������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401220003', '1', '�ʶ�֧��˾ԣ¡���ܹ���վ������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3414000000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3414009900', '1', '����֧��˾������ũҵ�ղ�', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3414000500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3414000400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3414000300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3414000200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3414000100', '1', '����֧��˾�ܾ�����', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3414001200', '1', '�ӳ���ũҵ���շ���', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3414001900', '1', '������ũҵ���շ���', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3414000800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3414000003', '1', '����ŷ����ó������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3414000100', '1', '����֧��˾�ܾ�����', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3414001200', '1', '�ӳ���ũҵ���շ���', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3414001900', '1', '������ũҵ���շ���', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3414000800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3414000003', '1', '����ŷ����ó������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3414000004', '1', '�����Žᶫ·֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3414000005', '1', '����Ӣ��֮���������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3414000006', '1', '�����������������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000200', '1', '�Ϸ�����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000300', '1', '�Ϸ�����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000400', '1', '�Ϸ�����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400006600', '1', '���չ�����˾', '1', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400006601', '1', '��̫���չ���', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3414210000', '1', '®��֧��˾', '1', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3414210200', '1', '®��֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3414210100', '1', '®��֧��˾������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3414210600', '1', '®��֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3414210700', '1', '®��֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3414219900', '1', '®��֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3414210002', '1', '®��ũ��վ������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3414210001', '1', '����®����Խ����������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3414210003', '1', '®�������ǳ�����', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401210000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401210100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401210200', '1', '����֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401210600', '1', '����֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401210700', '1', '����֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401219900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401210002', '1', '�����Դ����վ������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401210001', '1', '����ũ��վ������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401212000', '1', '����֧��˾����Ӫ������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000002', '1', '�Ϸ�����֧��˾������ó������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000006', '1', '�Ϸ�����֧��˾����������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000005', '1', '�Ϸ�����֧��˾������������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400009900', '1', '�Ϸ�����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000010', '1', '�Ϸ�����֧��˾�������������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000009', '1', '�Ϸ�����֧��˾������ó������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000004', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000800', '1', '�Ϸ�����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000900', '1', '�Ϸ�����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000011', '1', '�Ϸ�����֧��˾��̩���մ���������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000014', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000015', '1', '�Ϸ�����֧��˾��̩����������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000012', '1', '�Ϸ�����֧��˾���Ǳ��վ��ͳ�����', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000013', '1', '�Ϸ�����֧��˾����ɽ�������Ĵ���������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000003', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000008', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000007', '1', '�Ϸ�����֧��˾��˳��ó������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000016', '1', '�Ϸ�����֧��˾��÷�����������޹�˾', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000017', '1', '�Ϸ����������������޹�˾', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000018', '1', '�Ϸ�����·֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000019', '1', '�Ϸʽ�կ·��������֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401020000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401020100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401020200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401020300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401020400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401020500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401020800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401029900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401020001', '1', '����֧��˾�������ճ�����', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401020002', '1', '����֧��˾�����𰲱��ճ�����', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401020003', '1', '����֧��˾�������������������޹�˾', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000020', '1', '��������������۷������޹�˾', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401110000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401119900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401110001', '1', '�Ϸ��н����ػ��������޹�˾������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401110100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401110200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401110300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401110400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401110500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401110800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401110002', '1', '����֧��˾���ս����������۳�����', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401110003', '1', '����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401110004', '1', '����֧��˾�Ϸʲ��Ӻ�����ó������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401110005', '1', '����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000021', '1', '���հ��������������޹�˾������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000022', '1', '����Э�ͱ��մ�����Ǻ�ΰ������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000023', '1', '�����������մ����ʶ��ֹ�˾������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000024', '1', '�Ϸ��н�������������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000025', '1', '�Ϸ�����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000026', '1', '�Ϸ�����֧��˾���տ�������������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000027', '1', '�Ϸ�����֧��˾�Ϸ��������������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3414000004', '1', '�����Žᶫ·֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3414000005', '1', '����Ӣ��֮���������۷������޹�˾������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3414000006', '1', '�����������������۷������޹�˾������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000200', '1', '�Ϸ�����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000300', '1', '�Ϸ�����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000400', '1', '�Ϸ�����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400006600', '1', '���չ�����˾', '1', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400006601', '1', '��̫���չ���', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3414210000', '1', '®��֧��˾', '1', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3414210200', '1', '®��֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3414210100', '1', '®��֧��˾������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3414210600', '1', '®��֧��˾ҵ��', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3414210700', '1', '®��֧��˾���۲�', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3414219900', '1', '®��֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3414210002', '1', '®��ũ��վ������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3414210001', '1', '����®����Խ����������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3414210003', '1', '®�������ǳ�����', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401210000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401210100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401210200', '1', '����֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401210600', '1', '����֧��˾ҵ��', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401210700', '1', '����֧��˾���۲�', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401219900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401210002', '1', '�����Դ����վ������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401210001', '1', '����ũ��վ������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401212000', '1', '����֧��˾����Ӫ������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000002', '1', '�Ϸ�����֧��˾������ó������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000006', '1', '�Ϸ�����֧��˾����������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000005', '1', '�Ϸ�����֧��˾������������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400009900', '1', '�Ϸ�����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000010', '1', '�Ϸ�����֧��˾�������������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000009', '1', '�Ϸ�����֧��˾������ó������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000004', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000800', '1', '�Ϸ�����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000900', '1', '�Ϸ�����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000011', '1', '�Ϸ�����֧��˾��̩���մ���������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000014', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000015', '1', '�Ϸ�����֧��˾��̩����������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000012', '1', '�Ϸ�����֧��˾���Ǳ��վ��ͳ�����', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000013', '1', '�Ϸ�����֧��˾����ɽ�������Ĵ���������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000003', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000008', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000007', '1', '�Ϸ�����֧��˾��˳��ó������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000016', '1', '�Ϸ�����֧��˾��÷�����������޹�˾', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000017', '1', '�Ϸ����������������޹�˾', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000018', '1', '�Ϸ�����·֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000019', '1', '�Ϸʽ�կ·��������֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401020000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401020100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401020200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401020300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401020400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401020500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401020800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401029900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401020001', '1', '����֧��˾�������ճ�����', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401020002', '1', '����֧��˾�����𰲱��ճ�����', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401020003', '1', '����֧��˾�������������������޹�˾', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000020', '1', '��������������۷������޹�˾', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401110000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401119900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401110001', '1', '�Ϸ��н����ػ��������޹�˾������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401110100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401110200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401110300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401110400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401110500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401110800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401110002', '1', '����֧��˾���ս����������۳�����', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401110003', '1', '����֧��˾������������������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401110004', '1', '����֧��˾�Ϸʲ��Ӻ�����ó������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401110005', '1', '����֧��˾������������������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000021', '1', '���հ��������������޹�˾������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000022', '1', '����Э�ͱ��մ�����Ǻ�ΰ������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000023', '1', '�����������մ����ʶ��ֹ�˾������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000024', '1', '�Ϸ��н�������������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000025', '1', '�Ϸ�����֧��˾������������������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000026', '1', '�Ϸ�����֧��˾���տ�������������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000027', '1', '�Ϸ�����֧��˾�Ϸ��������������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000028', '1', '�Ϸ�����֧��˾�������ı��վ��ͳ�����', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000029', '1', '�Ϸ�����֧��˾���������������۳�����', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000030', '1', '�Ϸ�����֧��˾�����������Ƿֹ�˾������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000031', '1', '�Ϸ�����֧��˾�𰲱��մ���������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000028', '1', '�Ϸ�����֧��˾�������ı��վ��ͳ�����', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000029', '1', '�Ϸ�����֧��˾���������������۳�����', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000030', '1', '�Ϸ�����֧��˾�����������Ƿֹ�˾������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000031', '1', '�Ϸ�����֧��˾�𰲱��մ���������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000033', '1', '�Ϸ�����֧��˾������ó����������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000034', '1', '�Ϸ�����֧��˾���ջݷ�����������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000032', '1', '�Ϸ�����֧��˾���ջݺ�����������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000035', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000036', '1', '�Ϸ�����֧��˾���������������۹�˾������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000037', '1', '�����׺������������޹�˾������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000038', '1', '����̩Դ�������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401010000', '1', '�Ϸ�����֧��˾Ӫҵ��', '1', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401019900', '1', '�Ϸ�����֧��˾Ӫҵ��������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401010800', '1', '�Ϸ�����֧��˾Ӫҵ���ͻ�����', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401010500', '1', '�Ϸ�����֧��˾Ӫҵ��ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401010400', '1', '�Ϸ�����֧��˾Ӫҵ���Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401010300', '1', '�Ϸ�����֧��˾Ӫҵ�������Ʋ�', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401010200', '1', '�Ϸ�����֧��˾Ӫҵ���ۺϹ�����', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401010100', '1', '�Ϸ�����֧��˾Ӫҵ��������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401010001', '1', '�Ϸ���֧�����񰲱��մ���������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401010013', '1', '�Ϸ���֧Ӫҵ�����������������޹�˾������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401010004', '1', '�Ϸ���֧Ӫҵ��������������������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401010005', '1', '�Ϸ���֧Ӫҵ�����ջݷ�����������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401010006', '1', '�Ϸ���֧Ӫҵ�����ջݺ�����������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401010007', '1', '����̩Դ�������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401010002', '1', '�������˱������۹ɷݹɷݹ�˾���շֹ�˾������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401010012', '1', '�Ϸ���֧Ӫҵ����÷���մ������޹�˾���շֹ�˾', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401010010', '1', '�Ϸ���֧Ӫҵ�����鱣���������޹�˾���շֹ�˾', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401010014', '1', '�Ϸ���֧Ӫҵ������ͬ�±��մ������޹�˾������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401010003', '1', '�Ϸ���֧�����ɻ������г�������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401010008', '1', '�Ϸ���֧Ӫҵ����������������۳�����', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401010009', '1', '�Ϸ���֧Ӫҵ���Ϸ���ͨ�������۳�����', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401010011', '1', '�Ϸ���֧Ӫҵ������Э�ͱ��մ������޹�˾', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3401010015', '1', '�Ϸ���֧Ӫҵ���Ϸ���������������˾������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK315520180002', '3400000039', '1', '�Ϸ�����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:45:22', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000000', '1', '�Ϸ�����֧��˾', '1', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000100', '1', '�Ϸ�����֧��˾�ܾ�����', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401230000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401230100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401230001', '1', '����������ó������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401239900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401230700', '1', '����֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401230600', '1', '����֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401230200', '1', '����֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401230002', '1', '������ũ�û�е������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401232000', '1', 'С��ׯ��Ӫ������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401232100', '1', '����֧��˾��ͤӪ������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401220000', '1', '�ʶ�֧��˾', '1', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401229900', '1', '�ʶ�֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401220700', '1', '�ʶ�֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401220600', '1', '�ʶ�֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401220200', '1', '�ʶ�֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401220100', '1', '�ʶ�֧��˾������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401220001', '1', '�ʶ�ũ��վ������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401220002', '1', '���մ��籣�մ������޹�˾', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401222000', '1', '�ʶ�֧��˾�˶�Ӫ������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401220003', '1', '�ʶ�֧��˾ԣ¡���ܹ���վ������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3414000000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3414009900', '1', '����֧��˾������ũҵ�ղ�', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3414000500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3414000400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3414000300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3414000200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3414000100', '1', '����֧��˾�ܾ�����', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3414001200', '1', '�ӳ���ũҵ���շ���', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3414001900', '1', '������ũҵ���շ���', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3414000800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3414000003', '1', '����ŷ����ó������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3414000004', '1', '�����Žᶫ·֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3414000005', '1', '����Ӣ��֮���������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3414000006', '1', '�����������������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000200', '1', '�Ϸ�����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000300', '1', '�Ϸ�����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000400', '1', '�Ϸ�����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400006600', '1', '���չ�����˾', '1', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400006601', '1', '��̫���չ���', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3414210000', '1', '®��֧��˾', '1', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3414210200', '1', '®��֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3414210100', '1', '®��֧��˾������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3414210600', '1', '®��֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3414210700', '1', '®��֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3414219900', '1', '®��֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000033', '1', '�Ϸ�����֧��˾������ó����������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000034', '1', '�Ϸ�����֧��˾���ջݷ�����������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000032', '1', '�Ϸ�����֧��˾���ջݺ�����������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000035', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000036', '1', '�Ϸ�����֧��˾���������������۹�˾������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000037', '1', '�����׺������������޹�˾������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000038', '1', '����̩Դ�������۷������޹�˾������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401010000', '1', '�Ϸ�����֧��˾Ӫҵ��', '1', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401019900', '1', '�Ϸ�����֧��˾Ӫҵ��������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401010800', '1', '�Ϸ�����֧��˾Ӫҵ���ͻ�����', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401010500', '1', '�Ϸ�����֧��˾Ӫҵ��ũҵ���ղ�', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401010400', '1', '�Ϸ�����֧��˾Ӫҵ���Ʋ����ղ�', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401010300', '1', '�Ϸ�����֧��˾Ӫҵ�������Ʋ�', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401010200', '1', '�Ϸ�����֧��˾Ӫҵ���ۺϹ�����', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401010100', '1', '�Ϸ�����֧��˾Ӫҵ��������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401010001', '1', '�Ϸ���֧�����񰲱��մ���������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401010013', '1', '�Ϸ���֧Ӫҵ�����������������޹�˾������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401010004', '1', '�Ϸ���֧Ӫҵ��������������������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401010005', '1', '�Ϸ���֧Ӫҵ�����ջݷ�����������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401010006', '1', '�Ϸ���֧Ӫҵ�����ջݺ�����������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401010007', '1', '����̩Դ�������۷������޹�˾������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401010002', '1', '�������˱������۹ɷݹɷݹ�˾���շֹ�˾������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401010012', '1', '�Ϸ���֧Ӫҵ����÷���մ������޹�˾���շֹ�˾', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401010010', '1', '�Ϸ���֧Ӫҵ�����鱣���������޹�˾���շֹ�˾', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401010014', '1', '�Ϸ���֧Ӫҵ������ͬ�±��մ������޹�˾������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401010003', '1', '�Ϸ���֧�����ɻ������г�������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401010008', '1', '�Ϸ���֧Ӫҵ����������������۳�����', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401010009', '1', '�Ϸ���֧Ӫҵ���Ϸ���ͨ�������۳�����', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401010011', '1', '�Ϸ���֧Ӫҵ������Э�ͱ��մ������޹�˾', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3401010015', '1', '�Ϸ���֧Ӫҵ���Ϸ���������������˾������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK312920180001', '3400000039', '1', '�Ϸ�����֧��˾������������������', '0', '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000000', '1', '�Ϸ�����֧��˾', '1', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000100', '1', '�Ϸ�����֧��˾�ܾ�����', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401230000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401230100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401230001', '1', '����������ó������', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401239900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401230700', '1', '����֧��˾���۲�', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401230600', '1', '����֧��˾ҵ��', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401230200', '1', '����֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401230002', '1', '������ũ�û�е������', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401232000', '1', 'С��ׯ��Ӫ������', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401232100', '1', '����֧��˾��ͤӪ������', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401220000', '1', '�ʶ�֧��˾', '1', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401229900', '1', '�ʶ�֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401220700', '1', '�ʶ�֧��˾���۲�', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401220600', '1', '�ʶ�֧��˾ҵ��', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401220200', '1', '�ʶ�֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401220100', '1', '�ʶ�֧��˾������', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401220001', '1', '�ʶ�ũ��վ������', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401220002', '1', '���մ��籣�մ������޹�˾', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401222000', '1', '�ʶ�֧��˾�˶�Ӫ������', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401220003', '1', '�ʶ�֧��˾ԣ¡���ܹ���վ������', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3414000000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3414009900', '1', '����֧��˾������ũҵ�ղ�', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3414000500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3414000400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3414000300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3414000200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3414000100', '1', '����֧��˾�ܾ�����', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3414001200', '1', '�ӳ���ũҵ���շ���', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3414001900', '1', '������ũҵ���շ���', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3414000800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3414000003', '1', '����ŷ����ó������', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3414000004', '1', '�����Žᶫ·֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3414000005', '1', '����Ӣ��֮���������۷������޹�˾������', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3414000006', '1', '�����������������۷������޹�˾������', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000200', '1', '�Ϸ�����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000300', '1', '�Ϸ�����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000400', '1', '�Ϸ�����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400006600', '1', '���չ�����˾', '1', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400006601', '1', '��̫���չ���', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3414210000', '1', '®��֧��˾', '1', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3414210200', '1', '®��֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3414210100', '1', '®��֧��˾������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3414210600', '1', '®��֧��˾ҵ��', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3414210700', '1', '®��֧��˾���۲�', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3414219900', '1', '®��֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3414210002', '1', '®��ũ��վ������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3414210001', '1', '����®����Խ����������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3414210003', '1', '®�������ǳ�����', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401210000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401210100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3414210002', '1', '®��ũ��վ������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3414210001', '1', '����®����Խ����������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3414210003', '1', '®�������ǳ�����', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401210000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401210100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401210200', '1', '����֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401210600', '1', '����֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401210700', '1', '����֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401219900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401210002', '1', '�����Դ����վ������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401210001', '1', '����ũ��վ������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401212000', '1', '����֧��˾����Ӫ������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000002', '1', '�Ϸ�����֧��˾������ó������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000006', '1', '�Ϸ�����֧��˾����������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000005', '1', '�Ϸ�����֧��˾������������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400009900', '1', '�Ϸ�����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000010', '1', '�Ϸ�����֧��˾�������������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000009', '1', '�Ϸ�����֧��˾������ó������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000004', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000800', '1', '�Ϸ�����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000900', '1', '�Ϸ�����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000011', '1', '�Ϸ�����֧��˾��̩���մ���������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000014', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000015', '1', '�Ϸ�����֧��˾��̩����������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000012', '1', '�Ϸ�����֧��˾���Ǳ��վ��ͳ�����', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000013', '1', '�Ϸ�����֧��˾����ɽ�������Ĵ���������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000003', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000008', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000007', '1', '�Ϸ�����֧��˾��˳��ó������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000016', '1', '�Ϸ�����֧��˾��÷�����������޹�˾', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000017', '1', '�Ϸ����������������޹�˾', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000018', '1', '�Ϸ�����·֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000019', '1', '�Ϸʽ�կ·��������֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401020000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401020100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401020200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401020300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401020400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401020500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401020800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401029900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401020001', '1', '����֧��˾�������ճ�����', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401020002', '1', '����֧��˾�����𰲱��ճ�����', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401020003', '1', '����֧��˾�������������������޹�˾', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000020', '1', '��������������۷������޹�˾', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401110000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401119900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401110001', '1', '�Ϸ��н����ػ��������޹�˾������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401110100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401110200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401110300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401110400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401110500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401110800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401110002', '1', '����֧��˾���ս����������۳�����', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401110003', '1', '����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401110004', '1', '����֧��˾�Ϸʲ��Ӻ�����ó������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401110005', '1', '����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000021', '1', '���հ��������������޹�˾������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000022', '1', '����Э�ͱ��մ�����Ǻ�ΰ������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000023', '1', '�����������մ����ʶ��ֹ�˾������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000024', '1', '�Ϸ��н�������������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000025', '1', '�Ϸ�����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000026', '1', '�Ϸ�����֧��˾���տ�������������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000027', '1', '�Ϸ�����֧��˾�Ϸ��������������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000028', '1', '�Ϸ�����֧��˾�������ı��վ��ͳ�����', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000029', '1', '�Ϸ�����֧��˾���������������۳�����', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000030', '1', '�Ϸ�����֧��˾�����������Ƿֹ�˾������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000031', '1', '�Ϸ�����֧��˾�𰲱��մ���������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000033', '1', '�Ϸ�����֧��˾������ó����������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000034', '1', '�Ϸ�����֧��˾���ջݷ�����������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000032', '1', '�Ϸ�����֧��˾���ջݺ�����������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000035', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000036', '1', '�Ϸ�����֧��˾���������������۹�˾������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000037', '1', '�����׺������������޹�˾������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000038', '1', '����̩Դ�������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401010000', '1', '�Ϸ�����֧��˾Ӫҵ��', '1', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401019900', '1', '�Ϸ�����֧��˾Ӫҵ��������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401010800', '1', '�Ϸ�����֧��˾Ӫҵ���ͻ�����', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401010500', '1', '�Ϸ�����֧��˾Ӫҵ��ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401010400', '1', '�Ϸ�����֧��˾Ӫҵ���Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401010300', '1', '�Ϸ�����֧��˾Ӫҵ�������Ʋ�', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401210200', '1', '����֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401210600', '1', '����֧��˾ҵ��', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401210700', '1', '����֧��˾���۲�', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401219900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401210002', '1', '�����Դ����վ������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401210001', '1', '����ũ��վ������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401212000', '1', '����֧��˾����Ӫ������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000002', '1', '�Ϸ�����֧��˾������ó������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000006', '1', '�Ϸ�����֧��˾����������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000005', '1', '�Ϸ�����֧��˾������������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400009900', '1', '�Ϸ�����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000010', '1', '�Ϸ�����֧��˾�������������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000009', '1', '�Ϸ�����֧��˾������ó������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000004', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000800', '1', '�Ϸ�����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000900', '1', '�Ϸ�����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000011', '1', '�Ϸ�����֧��˾��̩���մ���������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000014', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000015', '1', '�Ϸ�����֧��˾��̩����������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000012', '1', '�Ϸ�����֧��˾���Ǳ��վ��ͳ�����', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000013', '1', '�Ϸ�����֧��˾����ɽ�������Ĵ���������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000003', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000008', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000007', '1', '�Ϸ�����֧��˾��˳��ó������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000016', '1', '�Ϸ�����֧��˾��÷�����������޹�˾', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000017', '1', '�Ϸ����������������޹�˾', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000018', '1', '�Ϸ�����·֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000019', '1', '�Ϸʽ�կ·��������֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401020000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401020100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401020200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401020300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401020400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401020500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401020800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401029900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401020001', '1', '����֧��˾�������ճ�����', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401020002', '1', '����֧��˾�����𰲱��ճ�����', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401020003', '1', '����֧��˾�������������������޹�˾', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000020', '1', '��������������۷������޹�˾', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401110000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401119900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401110001', '1', '�Ϸ��н����ػ��������޹�˾������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401110100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401110200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401110300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401110400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401110500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401110800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401110002', '1', '����֧��˾���ս����������۳�����', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401110003', '1', '����֧��˾������������������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401110004', '1', '����֧��˾�Ϸʲ��Ӻ�����ó������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401110005', '1', '����֧��˾������������������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000021', '1', '���հ��������������޹�˾������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000022', '1', '����Э�ͱ��մ�����Ǻ�ΰ������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000023', '1', '�����������մ����ʶ��ֹ�˾������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000024', '1', '�Ϸ��н�������������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000025', '1', '�Ϸ�����֧��˾������������������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000026', '1', '�Ϸ�����֧��˾���տ�������������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000027', '1', '�Ϸ�����֧��˾�Ϸ��������������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000028', '1', '�Ϸ�����֧��˾�������ı��վ��ͳ�����', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000029', '1', '�Ϸ�����֧��˾���������������۳�����', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000030', '1', '�Ϸ�����֧��˾�����������Ƿֹ�˾������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000031', '1', '�Ϸ�����֧��˾�𰲱��մ���������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000033', '1', '�Ϸ�����֧��˾������ó����������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000034', '1', '�Ϸ�����֧��˾���ջݷ�����������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000032', '1', '�Ϸ�����֧��˾���ջݺ�����������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000035', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000036', '1', '�Ϸ�����֧��˾���������������۹�˾������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000037', '1', '�����׺������������޹�˾������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000038', '1', '����̩Դ�������۷������޹�˾������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401010000', '1', '�Ϸ�����֧��˾Ӫҵ��', '1', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401019900', '1', '�Ϸ�����֧��˾Ӫҵ��������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401010800', '1', '�Ϸ�����֧��˾Ӫҵ���ͻ�����', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401010500', '1', '�Ϸ�����֧��˾Ӫҵ��ũҵ���ղ�', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401010400', '1', '�Ϸ�����֧��˾Ӫҵ���Ʋ����ղ�', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401010300', '1', '�Ϸ�����֧��˾Ӫҵ�������Ʋ�', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401010200', '1', '�Ϸ�����֧��˾Ӫҵ���ۺϹ�����', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401010100', '1', '�Ϸ�����֧��˾Ӫҵ��������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401010001', '1', '�Ϸ���֧�����񰲱��մ���������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401010013', '1', '�Ϸ���֧Ӫҵ�����������������޹�˾������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401010200', '1', '�Ϸ�����֧��˾Ӫҵ���ۺϹ�����', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401010100', '1', '�Ϸ�����֧��˾Ӫҵ��������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401010001', '1', '�Ϸ���֧�����񰲱��մ���������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401010013', '1', '�Ϸ���֧Ӫҵ�����������������޹�˾������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401010004', '1', '�Ϸ���֧Ӫҵ��������������������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401010005', '1', '�Ϸ���֧Ӫҵ�����ջݷ�����������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401010006', '1', '�Ϸ���֧Ӫҵ�����ջݺ�����������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401010007', '1', '����̩Դ�������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401010002', '1', '�������˱������۹ɷݹɷݹ�˾���շֹ�˾������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401010012', '1', '�Ϸ���֧Ӫҵ����÷���մ������޹�˾���շֹ�˾', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401010010', '1', '�Ϸ���֧Ӫҵ�����鱣���������޹�˾���շֹ�˾', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401010014', '1', '�Ϸ���֧Ӫҵ������ͬ�±��մ������޹�˾������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401010003', '1', '�Ϸ���֧�����ɻ������г�������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401010008', '1', '�Ϸ���֧Ӫҵ����������������۳�����', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401010009', '1', '�Ϸ���֧Ӫҵ���Ϸ���ͨ�������۳�����', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401010011', '1', '�Ϸ���֧Ӫҵ������Э�ͱ��մ������޹�˾', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3401010015', '1', '�Ϸ���֧Ӫҵ���Ϸ���������������˾������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK316220180001', '3400000039', '1', '�Ϸ�����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:49:27', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000000', '1', '�Ϸ�����֧��˾', '1', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000100', '1', '�Ϸ�����֧��˾�ܾ�����', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401230000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401230100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401230001', '1', '����������ó������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401239900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401230700', '1', '����֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401230600', '1', '����֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401230200', '1', '����֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401230002', '1', '������ũ�û�е������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401232000', '1', 'С��ׯ��Ӫ������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401232100', '1', '����֧��˾��ͤӪ������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401220000', '1', '�ʶ�֧��˾', '1', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401229900', '1', '�ʶ�֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401220700', '1', '�ʶ�֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401220600', '1', '�ʶ�֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401220200', '1', '�ʶ�֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401220100', '1', '�ʶ�֧��˾������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401220001', '1', '�ʶ�ũ��վ������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401220002', '1', '���մ��籣�մ������޹�˾', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401222000', '1', '�ʶ�֧��˾�˶�Ӫ������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401220003', '1', '�ʶ�֧��˾ԣ¡���ܹ���վ������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3414000000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3414009900', '1', '����֧��˾������ũҵ�ղ�', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3414000500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3414000400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3414000300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3414000200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3414000100', '1', '����֧��˾�ܾ�����', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3414001200', '1', '�ӳ���ũҵ���շ���', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3414001900', '1', '������ũҵ���շ���', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3414000800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3414000003', '1', '����ŷ����ó������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3414000004', '1', '�����Žᶫ·֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3414000005', '1', '����Ӣ��֮���������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3414000006', '1', '�����������������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000200', '1', '�Ϸ�����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000300', '1', '�Ϸ�����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000400', '1', '�Ϸ�����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400006600', '1', '���չ�����˾', '1', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400006601', '1', '��̫���չ���', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3414210000', '1', '®��֧��˾', '1', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3414210200', '1', '®��֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3414210100', '1', '®��֧��˾������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3414210600', '1', '®��֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3414210700', '1', '®��֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3414219900', '1', '®��֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3414210002', '1', '®��ũ��վ������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3414210001', '1', '����®����Խ����������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3414210003', '1', '®�������ǳ�����', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401210000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401210100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401210200', '1', '����֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401210600', '1', '����֧��˾ҵ��', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401210700', '1', '����֧��˾���۲�', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401219900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401210002', '1', '�����Դ����վ������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401210001', '1', '����ũ��վ������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401212000', '1', '����֧��˾����Ӫ������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000002', '1', '�Ϸ�����֧��˾������ó������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000006', '1', '�Ϸ�����֧��˾����������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000005', '1', '�Ϸ�����֧��˾������������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400009900', '1', '�Ϸ�����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000010', '1', '�Ϸ�����֧��˾�������������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000009', '1', '�Ϸ�����֧��˾������ó������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000004', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401010004', '1', '�Ϸ���֧Ӫҵ��������������������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401010005', '1', '�Ϸ���֧Ӫҵ�����ջݷ�����������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401010006', '1', '�Ϸ���֧Ӫҵ�����ջݺ�����������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401010007', '1', '����̩Դ�������۷������޹�˾������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401010002', '1', '�������˱������۹ɷݹɷݹ�˾���շֹ�˾������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401010012', '1', '�Ϸ���֧Ӫҵ����÷���մ������޹�˾���շֹ�˾', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401010010', '1', '�Ϸ���֧Ӫҵ�����鱣���������޹�˾���շֹ�˾', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401010014', '1', '�Ϸ���֧Ӫҵ������ͬ�±��մ������޹�˾������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401010003', '1', '�Ϸ���֧�����ɻ������г�������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401010008', '1', '�Ϸ���֧Ӫҵ����������������۳�����', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401010009', '1', '�Ϸ���֧Ӫҵ���Ϸ���ͨ�������۳�����', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401010011', '1', '�Ϸ���֧Ӫҵ������Э�ͱ��մ������޹�˾', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3401010015', '1', '�Ϸ���֧Ӫҵ���Ϸ���������������˾������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180001', '3400000039', '1', '�Ϸ�����֧��˾������������������', '0', '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:10:13', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000000', '1', '�Ϸ�����֧��˾', '1', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000100', '1', '�Ϸ�����֧��˾�ܾ�����', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401230000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401230100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401230001', '1', '����������ó������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401239900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401230700', '1', '����֧��˾���۲�', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401230600', '1', '����֧��˾ҵ��', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401230200', '1', '����֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401230002', '1', '������ũ�û�е������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401232000', '1', 'С��ׯ��Ӫ������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401232100', '1', '����֧��˾��ͤӪ������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401220000', '1', '�ʶ�֧��˾', '1', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401229900', '1', '�ʶ�֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401220700', '1', '�ʶ�֧��˾���۲�', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401220600', '1', '�ʶ�֧��˾ҵ��', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401220200', '1', '�ʶ�֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401220100', '1', '�ʶ�֧��˾������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401220001', '1', '�ʶ�ũ��վ������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401220002', '1', '���մ��籣�մ������޹�˾', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401222000', '1', '�ʶ�֧��˾�˶�Ӫ������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401220003', '1', '�ʶ�֧��˾ԣ¡���ܹ���վ������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3414000000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3414009900', '1', '����֧��˾������ũҵ�ղ�', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3414000500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3414000400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3414000300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3414000200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3414000100', '1', '����֧��˾�ܾ�����', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3414001200', '1', '�ӳ���ũҵ���շ���', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3414001900', '1', '������ũҵ���շ���', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3414000800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3414000003', '1', '����ŷ����ó������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3414000004', '1', '�����Žᶫ·֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3414000005', '1', '����Ӣ��֮���������۷������޹�˾������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3414000006', '1', '�����������������۷������޹�˾������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000200', '1', '�Ϸ�����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000300', '1', '�Ϸ�����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000400', '1', '�Ϸ�����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400006600', '1', '���չ�����˾', '1', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400006601', '1', '��̫���չ���', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3414210000', '1', '®��֧��˾', '1', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3414210200', '1', '®��֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3414210100', '1', '®��֧��˾������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3414210600', '1', '®��֧��˾ҵ��', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3414210700', '1', '®��֧��˾���۲�', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3414219900', '1', '®��֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3414210002', '1', '®��ũ��վ������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3414210001', '1', '����®����Խ����������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3414210003', '1', '®�������ǳ�����', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401210000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401210100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401210200', '1', '����֧��˾�ۺϲ�', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401210600', '1', '����֧��˾ҵ��', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401210700', '1', '����֧��˾���۲�', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401219900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401210002', '1', '�����Դ����վ������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401210001', '1', '����ũ��վ������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401212000', '1', '����֧��˾����Ӫ������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000002', '1', '�Ϸ�����֧��˾������ó������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000006', '1', '�Ϸ�����֧��˾����������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000005', '1', '�Ϸ�����֧��˾������������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400009900', '1', '�Ϸ�����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000010', '1', '�Ϸ�����֧��˾�������������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000009', '1', '�Ϸ�����֧��˾������ó������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000004', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000800', '1', '�Ϸ�����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000900', '1', '�Ϸ�����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000011', '1', '�Ϸ�����֧��˾��̩���մ���������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000014', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000015', '1', '�Ϸ�����֧��˾��̩����������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000800', '1', '�Ϸ�����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000900', '1', '�Ϸ�����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000011', '1', '�Ϸ�����֧��˾��̩���մ���������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000014', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000015', '1', '�Ϸ�����֧��˾��̩����������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000012', '1', '�Ϸ�����֧��˾���Ǳ��վ��ͳ�����', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000013', '1', '�Ϸ�����֧��˾����ɽ�������Ĵ���������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000003', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000008', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000007', '1', '�Ϸ�����֧��˾��˳��ó������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000016', '1', '�Ϸ�����֧��˾��÷�����������޹�˾', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000017', '1', '�Ϸ����������������޹�˾', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000018', '1', '�Ϸ�����·֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000019', '1', '�Ϸʽ�կ·��������֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401020000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401020100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401020200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401020300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401020400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401020500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401020800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401029900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401020001', '1', '����֧��˾�������ճ�����', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401020002', '1', '����֧��˾�����𰲱��ճ�����', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401020003', '1', '����֧��˾�������������������޹�˾', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000020', '1', '��������������۷������޹�˾', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401110000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401119900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401110001', '1', '�Ϸ��н����ػ��������޹�˾������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401110100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401110200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401110300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401110400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401110500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401110800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401110002', '1', '����֧��˾���ս����������۳�����', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401110003', '1', '����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401110004', '1', '����֧��˾�Ϸʲ��Ӻ�����ó������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401110005', '1', '����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000021', '1', '���հ��������������޹�˾������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000022', '1', '����Э�ͱ��մ�����Ǻ�ΰ������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000023', '1', '�����������մ����ʶ��ֹ�˾������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000024', '1', '�Ϸ��н�������������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000025', '1', '�Ϸ�����֧��˾������������������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000026', '1', '�Ϸ�����֧��˾���տ�������������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000027', '1', '�Ϸ�����֧��˾�Ϸ��������������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000028', '1', '�Ϸ�����֧��˾�������ı��վ��ͳ�����', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000029', '1', '�Ϸ�����֧��˾���������������۳�����', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000030', '1', '�Ϸ�����֧��˾�����������Ƿֹ�˾������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000031', '1', '�Ϸ�����֧��˾�𰲱��մ���������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000033', '1', '�Ϸ�����֧��˾������ó����������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000034', '1', '�Ϸ�����֧��˾���ջݷ�����������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000032', '1', '�Ϸ�����֧��˾���ջݺ�����������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000035', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000036', '1', '�Ϸ�����֧��˾���������������۹�˾������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000037', '1', '�����׺������������޹�˾������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3400000038', '1', '����̩Դ�������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401010000', '1', '�Ϸ�����֧��˾Ӫҵ��', '1', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401019900', '1', '�Ϸ�����֧��˾Ӫҵ��������ũ��ҵ��', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401010800', '1', '�Ϸ�����֧��˾Ӫҵ���ͻ�����', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401010500', '1', '�Ϸ�����֧��˾Ӫҵ��ũҵ���ղ�', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401010400', '1', '�Ϸ�����֧��˾Ӫҵ���Ʋ����ղ�', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401010300', '1', '�Ϸ�����֧��˾Ӫҵ�������Ʋ�', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401010200', '1', '�Ϸ�����֧��˾Ӫҵ���ۺϹ�����', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401010100', '1', '�Ϸ�����֧��˾Ӫҵ��������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401010001', '1', '�Ϸ���֧�����񰲱��մ���������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401010013', '1', '�Ϸ���֧Ӫҵ�����������������޹�˾������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401010004', '1', '�Ϸ���֧Ӫҵ��������������������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401010005', '1', '�Ϸ���֧Ӫҵ�����ջݷ�����������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401010006', '1', '�Ϸ���֧Ӫҵ�����ջݺ�����������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401010007', '1', '����̩Դ�������۷������޹�˾������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401010002', '1', '�������˱������۹ɷݹɷݹ�˾���շֹ�˾������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401010012', '1', '�Ϸ���֧Ӫҵ����÷���մ������޹�˾���շֹ�˾', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401010010', '1', '�Ϸ���֧Ӫҵ�����鱣���������޹�˾���շֹ�˾', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401010014', '1', '�Ϸ���֧Ӫҵ������ͬ�±��մ������޹�˾������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401010003', '1', '�Ϸ���֧�����ɻ������г�������', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401010008', '1', '�Ϸ���֧Ӫҵ����������������۳�����', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401010009', '1', '�Ϸ���֧Ӫҵ���Ϸ���ͨ�������۳�����', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313020180004', '3401010011', '1', '�Ϸ���֧Ӫҵ������Э�ͱ��մ������޹�˾', '0', '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 12:53:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000012', '1', '�Ϸ�����֧��˾���Ǳ��վ��ͳ�����', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000013', '1', '�Ϸ�����֧��˾����ɽ�������Ĵ���������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000003', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000008', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000007', '1', '�Ϸ�����֧��˾��˳��ó������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000016', '1', '�Ϸ�����֧��˾��÷�����������޹�˾', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000017', '1', '�Ϸ����������������޹�˾', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000018', '1', '�Ϸ�����·֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000019', '1', '�Ϸʽ�կ·��������֤ȯӪҵ��������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401020000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401020100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401020200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401020300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401020400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401020500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401020800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401029900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401020001', '1', '����֧��˾�������ճ�����', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401020002', '1', '����֧��˾�����𰲱��ճ�����', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401020003', '1', '����֧��˾�������������������޹�˾', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000020', '1', '��������������۷������޹�˾', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401110000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401119900', '1', '����֧��˾������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401110001', '1', '�Ϸ��н����ػ��������޹�˾������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401110100', '1', '����֧��˾������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401110200', '1', '����֧��˾�ۺϹ�����', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401110300', '1', '����֧��˾�����Ʋ�', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401110400', '1', '����֧��˾�Ʋ����ղ�', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401110500', '1', '����֧��˾ũҵ���ղ�', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401110800', '1', '����֧��˾�ͻ�����', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401110002', '1', '����֧��˾���ս����������۳�����', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401110003', '1', '����֧��˾������������������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401110004', '1', '����֧��˾�Ϸʲ��Ӻ�����ó������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401110005', '1', '����֧��˾������������������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000021', '1', '���հ��������������޹�˾������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000022', '1', '����Э�ͱ��մ�����Ǻ�ΰ������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000023', '1', '�����������մ����ʶ��ֹ�˾������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000024', '1', '�Ϸ��н�������������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000025', '1', '�Ϸ�����֧��˾������������������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000026', '1', '�Ϸ�����֧��˾���տ�������������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000027', '1', '�Ϸ�����֧��˾�Ϸ��������������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000028', '1', '�Ϸ�����֧��˾�������ı��վ��ͳ�����', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000029', '1', '�Ϸ�����֧��˾���������������۳�����', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000030', '1', '�Ϸ�����֧��˾�����������Ƿֹ�˾������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000031', '1', '�Ϸ�����֧��˾�𰲱��մ���������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000033', '1', '�Ϸ�����֧��˾������ó����������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000034', '1', '�Ϸ�����֧��˾���ջݷ�����������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000032', '1', '�Ϸ�����֧��˾���ջݺ�����������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000035', '1', '�Ϸ�����֧��˾��������������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000036', '1', '�Ϸ�����֧��˾���������������۹�˾������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000037', '1', '�����׺������������޹�˾������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000038', '1', '����̩Դ�������۷������޹�˾������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401010000', '1', '�Ϸ�����֧��˾Ӫҵ��', '1', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401019900', '1', '�Ϸ�����֧��˾Ӫҵ��������ũ��ҵ��', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401010800', '1', '�Ϸ�����֧��˾Ӫҵ���ͻ�����', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401010500', '1', '�Ϸ�����֧��˾Ӫҵ��ũҵ���ղ�', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401010400', '1', '�Ϸ�����֧��˾Ӫҵ���Ʋ����ղ�', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401010300', '1', '�Ϸ�����֧��˾Ӫҵ�������Ʋ�', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401010200', '1', '�Ϸ�����֧��˾Ӫҵ���ۺϹ�����', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401010100', '1', '�Ϸ�����֧��˾Ӫҵ��������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401010001', '1', '�Ϸ���֧�����񰲱��մ���������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401010013', '1', '�Ϸ���֧Ӫҵ�����������������޹�˾������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401010004', '1', '�Ϸ���֧Ӫҵ��������������������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401010005', '1', '�Ϸ���֧Ӫҵ�����ջݷ�����������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401010006', '1', '�Ϸ���֧Ӫҵ�����ջݺ�����������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401010007', '1', '����̩Դ�������۷������޹�˾������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401010002', '1', '�������˱������۹ɷݹɷݹ�˾���շֹ�˾������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401010012', '1', '�Ϸ���֧Ӫҵ����÷���մ������޹�˾���շֹ�˾', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401010010', '1', '�Ϸ���֧Ӫҵ�����鱣���������޹�˾���շֹ�˾', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401010014', '1', '�Ϸ���֧Ӫҵ������ͬ�±��մ������޹�˾������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401010003', '1', '�Ϸ���֧�����ɻ������г�������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401010008', '1', '�Ϸ���֧Ӫҵ����������������۳�����', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401010009', '1', '�Ϸ���֧Ӫҵ���Ϸ���ͨ�������۳�����', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401010011', '1', '�Ϸ���֧Ӫҵ������Э�ͱ��մ������޹�˾', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3401010015', '1', '�Ϸ���֧Ӫҵ���Ϸ���������������˾������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322020180004', '3400000039', '1', '�Ϸ�����֧��˾������������������', '0', '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:12:21', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000000', '1', '�Ϸ�����֧��˾', '1', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3400000100', '1', '�Ϸ�����֧��˾�ܾ�����', '0', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK323720180001', '3401230000', '1', '����֧��˾', '1', '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'), '0537', to_date('02-05-2018 13:15:10', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', '4266000000', '1', '�����ֹ�˾ֱ��ҵ��', '1', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', '4266002001', '1', '�����ֹ�˾ֱ��ҵ��˫��Ӫ������', '0', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', '4266002002', '1', '�����ֹ�˾ֱ��ҵ��������Ӫ������', '0', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', '4266000002', '1', '�������մ���������', '0', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', '4266000003', '1', '���˱��մ���������', '0', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', '4266000004', '1', '·ͨ���մ���������', '0', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', '4266000100', '1', '�����ֹ�˾ֱ��ҵ�񲿾�����', '0', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', '4266000200', '1', '�����ֹ�˾ֱ��ҵ���ۺϹ�����', '0', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', '4266000300', '1', '�����ֹ�˾ֱ��ҵ�񲿲����Ʋ�', '0', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', '4266000800', '1', '�����ֹ�˾ֱ��ҵ�񲿿ͻ�����', '0', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', '4266009900', '1', '�����ֹ�˾ֱ��ҵ��������ũҵ�ղ�', '0', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', '4266000600', '1', '�����ֹ�˾ֱ��ҵ��ҵ�����۲�', '0', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', '4266000007', '1', '�����»��������������޹�˾������', '0', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', '4266000008', '1', '�人�ڻ�ͨͶ�ʹ������޹�˾������', '0', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', '4266001100', '1', '�����ֹ�˾ֱ��ҵ���人ֱ��ҵ��', '0', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', '4266001200', '1', '�����ֹ�˾ֱ��ҵ���人�ص�ͻ���', '0', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', '4266000009', '1', '�������ñ��մ���������', '0', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', '4266000010', '1', '����ֱ�������ر��ճ�����', '0', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', '4266000014', '1', '����ʢ�����ٱ��մ���Ӧ�Ƿֹ�˾������', '0', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', '4266000015', '1', '�������������������۷����������ι�˾������', '0', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', '4266000016', '1', 'ʢ�����ں����ֹ�˾������', '0', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', '4266000017', '1', '�人�������ڱ�������ֱ��ҵ�񲿳�����', '0', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK314120180004', '4266000018', '1', '�����������±��մ������޹�˾�����ֹ�˾������', '0', '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:46:20', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', '4266000000', '1', '�����ֹ�˾ֱ��ҵ��', '1', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', '4266002001', '1', '�����ֹ�˾ֱ��ҵ��˫��Ӫ������', '0', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', '4266002002', '1', '�����ֹ�˾ֱ��ҵ��������Ӫ������', '0', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', '4266000002', '1', '�������մ���������', '0', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', '4266000003', '1', '���˱��մ���������', '0', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', '4266000004', '1', '·ͨ���մ���������', '0', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', '4266000100', '1', '�����ֹ�˾ֱ��ҵ�񲿾�����', '0', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', '4266000200', '1', '�����ֹ�˾ֱ��ҵ���ۺϹ�����', '0', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', '4266000300', '1', '�����ֹ�˾ֱ��ҵ�񲿲����Ʋ�', '0', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', '4266000800', '1', '�����ֹ�˾ֱ��ҵ�񲿿ͻ�����', '0', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', '4266009900', '1', '�����ֹ�˾ֱ��ҵ��������ũҵ�ղ�', '0', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', '4266000600', '1', '�����ֹ�˾ֱ��ҵ��ҵ�����۲�', '0', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', '4266000007', '1', '�����»��������������޹�˾������', '0', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', '4266000008', '1', '�人�ڻ�ͨͶ�ʹ������޹�˾������', '0', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', '4266001100', '1', '�����ֹ�˾ֱ��ҵ���人ֱ��ҵ��', '0', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', '4266001200', '1', '�����ֹ�˾ֱ��ҵ���人�ص�ͻ���', '0', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', '4266000009', '1', '�������ñ��մ���������', '0', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', '4266000010', '1', '����ֱ�������ر��ճ�����', '0', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', '4266000014', '1', '����ʢ�����ٱ��մ���Ӧ�Ƿֹ�˾������', '0', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', '4266000015', '1', '�������������������۷����������ι�˾������', '0', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', '4266000016', '1', 'ʢ�����ں����ֹ�˾������', '0', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', '4266000017', '1', '�人�������ڱ�������ֱ��ҵ�񲿳�����', '0', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK313420180002', '4266000018', '1', '�����������±��մ������޹�˾�����ֹ�˾������', '0', '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:48:31', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', '4266000000', '1', '�����ֹ�˾ֱ��ҵ��', '1', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', '4266002001', '1', '�����ֹ�˾ֱ��ҵ��˫��Ӫ������', '0', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', '4266002002', '1', '�����ֹ�˾ֱ��ҵ��������Ӫ������', '0', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', '4266000002', '1', '�������մ���������', '0', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', '4266000003', '1', '���˱��մ���������', '0', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', '4266000004', '1', '·ͨ���մ���������', '0', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', '4266000100', '1', '�����ֹ�˾ֱ��ҵ�񲿾�����', '0', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', '4266000200', '1', '�����ֹ�˾ֱ��ҵ���ۺϹ�����', '0', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', '4266000300', '1', '�����ֹ�˾ֱ��ҵ�񲿲����Ʋ�', '0', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', '4266000800', '1', '�����ֹ�˾ֱ��ҵ�񲿿ͻ�����', '0', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', '4266009900', '1', '�����ֹ�˾ֱ��ҵ��������ũҵ�ղ�', '0', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', '4266000600', '1', '�����ֹ�˾ֱ��ҵ��ҵ�����۲�', '0', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', '4266000007', '1', '�����»��������������޹�˾������', '0', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', '4266000008', '1', '�人�ڻ�ͨͶ�ʹ������޹�˾������', '0', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', '4266001100', '1', '�����ֹ�˾ֱ��ҵ���人ֱ��ҵ��', '0', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', '4266001200', '1', '�����ֹ�˾ֱ��ҵ���人�ص�ͻ���', '0', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', '4266000009', '1', '�������ñ��մ���������', '0', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', '4266000010', '1', '����ֱ�������ر��ճ�����', '0', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', '4266000014', '1', '����ʢ�����ٱ��մ���Ӧ�Ƿֹ�˾������', '0', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', '4266000015', '1', '�������������������۷����������ι�˾������', '0', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', '4266000016', '1', 'ʢ�����ں����ֹ�˾������', '0', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', '4266000017', '1', '�人�������ڱ�������ֱ��ҵ�񲿳�����', '0', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

insert into prpdclausecodecom (CLAUSECODE, COMCODE, FLAG, COMNAME, CONTAINFLAG, CREATEDBY, CREATEDTIME, UPDATEDBY, UPDATEDTIME)
values ('TK322420180002', '4266000018', '1', '�����������±��մ������޹�˾�����ֹ�˾������', '0', '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'), '42018', to_date('02-05-2018 13:50:58', 'dd-mm-yyyy hh24:mi:ss'));

prompt Done.
